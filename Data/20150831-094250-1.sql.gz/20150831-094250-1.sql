-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 127.0.0.1
-- Port     : 3306
-- Database : mulit
-- 
-- Part : #1
-- Date : 2015-08-31 09:42:50
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `onethink_action`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action`;
CREATE TABLE `onethink_action` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '行为唯一标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '行为说明',
  `remark` char(140) NOT NULL DEFAULT '' COMMENT '行为描述',
  `rule` text COMMENT '行为规则',
  `log` text COMMENT '日志规则',
  `type` tinyint(2) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='系统行为表';

-- -----------------------------
-- Records of `onethink_action`
-- -----------------------------
INSERT INTO `onethink_action` VALUES ('1', 'user_login', '用户登录', '积分+10，每天一次', 'table:member|field:score|condition:uid={$self} AND status>-1|rule:score+10|cycle:24|max:1;', '[user|get_nickname]在[time|time_format]登录了后台', '1', '1', '1387181220');
INSERT INTO `onethink_action` VALUES ('2', 'add_article', '发布文章', '积分+5，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:5', '', '2', '0', '1380173180');
INSERT INTO `onethink_action` VALUES ('3', 'review', '评论', '评论积分+1，无限制', 'table:member|field:score|condition:uid={$self}|rule:score+1', '', '2', '1', '1383285646');
INSERT INTO `onethink_action` VALUES ('4', 'add_document', '发表文档', '积分+10，每天上限5次', 'table:member|field:score|condition:uid={$self}|rule:score+10|cycle:24|max:5', '[user|get_nickname]在[time|time_format]发表了一篇文章。\r\n表[model]，记录编号[record]。', '2', '0', '1386139726');
INSERT INTO `onethink_action` VALUES ('5', 'add_document_topic', '发表讨论', '积分+5，每天上限10次', 'table:member|field:score|condition:uid={$self}|rule:score+5|cycle:24|max:10', '', '2', '0', '1383285551');
INSERT INTO `onethink_action` VALUES ('6', 'update_config', '更新配置', '新增或修改或删除配置', '', '', '1', '1', '1383294988');
INSERT INTO `onethink_action` VALUES ('7', 'update_model', '更新模型', '新增或修改模型', '', '', '1', '1', '1383295057');
INSERT INTO `onethink_action` VALUES ('8', 'update_attribute', '更新属性', '新增或更新或删除属性', '', '', '1', '1', '1383295963');
INSERT INTO `onethink_action` VALUES ('9', 'update_channel', '更新导航', '新增或修改或删除导航', '', '', '1', '1', '1383296301');
INSERT INTO `onethink_action` VALUES ('10', 'update_menu', '更新菜单', '新增或修改或删除菜单', '', '', '1', '1', '1383296392');
INSERT INTO `onethink_action` VALUES ('11', 'update_category', '更新分类', '新增或修改或删除分类', '', '', '1', '1', '1383296765');

-- -----------------------------
-- Table structure for `onethink_action_log`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_action_log`;
CREATE TABLE `onethink_action_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `action_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '行为id',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行用户id',
  `action_ip` bigint(20) NOT NULL COMMENT '执行行为者ip',
  `model` varchar(50) NOT NULL DEFAULT '' COMMENT '触发行为的表',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '触发行为的数据id',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '日志备注',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '执行行为的时间',
  PRIMARY KEY (`id`),
  KEY `action_ip_ix` (`action_ip`),
  KEY `action_id_ix` (`action_id`),
  KEY `user_id_ix` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=utf8 ROW_FORMAT=FIXED COMMENT='行为日志表';

-- -----------------------------
-- Records of `onethink_action_log`
-- -----------------------------
INSERT INTO `onethink_action_log` VALUES ('1', '1', '1', '454105574', 'member', '1', 'admin在2015-08-19 11:30登录了后台', '1', '1439955017');
INSERT INTO `onethink_action_log` VALUES ('2', '7', '1', '454105574', 'model', '6', '操作url：/admin.php?s=/Model/update.html', '1', '1439955061');
INSERT INTO `onethink_action_log` VALUES ('3', '7', '1', '454105574', 'model', '6', '操作url：/admin.php?s=/Model/update.html', '1', '1439955104');
INSERT INTO `onethink_action_log` VALUES ('4', '8', '1', '454105574', 'attribute', '47', '操作url：/admin.php?s=/Attribute/update.html', '1', '1439955265');
INSERT INTO `onethink_action_log` VALUES ('5', '7', '1', '454105574', 'model', '6', '操作url：/admin.php?s=/Model/update.html', '1', '1439955310');
INSERT INTO `onethink_action_log` VALUES ('6', '11', '1', '454105574', 'category', '1', '操作url：/admin.php?s=/Category/remove/id/1.html', '1', '1439955377');
INSERT INTO `onethink_action_log` VALUES ('7', '11', '1', '454105574', 'category', '2', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1439955409');
INSERT INTO `onethink_action_log` VALUES ('8', '11', '1', '454105574', 'category', '3', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1439955431');
INSERT INTO `onethink_action_log` VALUES ('9', '11', '1', '454105574', 'category', '4', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1439955456');
INSERT INTO `onethink_action_log` VALUES ('10', '11', '1', '454105574', 'category', '5', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1439955488');
INSERT INTO `onethink_action_log` VALUES ('11', '11', '1', '454105574', 'category', '6', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1439955510');
INSERT INTO `onethink_action_log` VALUES ('12', '11', '1', '454105574', 'category', '7', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1439955536');
INSERT INTO `onethink_action_log` VALUES ('13', '11', '1', '454105574', 'category', '8', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1439955566');
INSERT INTO `onethink_action_log` VALUES ('14', '11', '1', '454105574', 'category', '9', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1439955594');
INSERT INTO `onethink_action_log` VALUES ('15', '7', '1', '454105574', 'model', '2', '操作url：/admin.php?s=/Model/update.html', '1', '1439955681');
INSERT INTO `onethink_action_log` VALUES ('16', '8', '1', '454105574', 'attribute', '5', '操作url：/admin.php?s=/Attribute/update.html', '1', '1439956017');
INSERT INTO `onethink_action_log` VALUES ('17', '11', '1', '454105574', 'category', '10', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1439957548');
INSERT INTO `onethink_action_log` VALUES ('18', '1', '1', '454105574', 'member', '1', 'admin在2015-08-19 14:12登录了后台', '1', '1439964741');
INSERT INTO `onethink_action_log` VALUES ('19', '8', '1', '454105574', 'attribute', '48', '操作url：/admin.php?s=/Model/generate.html', '1', '1439966334');
INSERT INTO `onethink_action_log` VALUES ('20', '8', '1', '454105574', 'attribute', '49', '操作url：/admin.php?s=/Model/generate.html', '1', '1439966334');
INSERT INTO `onethink_action_log` VALUES ('21', '8', '1', '454105574', 'attribute', '50', '操作url：/admin.php?s=/Model/generate.html', '1', '1439966334');
INSERT INTO `onethink_action_log` VALUES ('22', '8', '1', '454105574', 'attribute', '51', '操作url：/admin.php?s=/Model/generate.html', '1', '1439966334');
INSERT INTO `onethink_action_log` VALUES ('23', '8', '1', '454105574', 'attribute', '52', '操作url：/admin.php?s=/Model/generate.html', '1', '1439966334');
INSERT INTO `onethink_action_log` VALUES ('24', '8', '1', '454105574', 'attribute', '53', '操作url：/admin.php?s=/Model/generate.html', '1', '1439966334');
INSERT INTO `onethink_action_log` VALUES ('25', '8', '1', '454105574', 'attribute', '54', '操作url：/admin.php?s=/Model/generate.html', '1', '1439966334');
INSERT INTO `onethink_action_log` VALUES ('26', '8', '1', '454105574', 'attribute', '55', '操作url：/admin.php?s=/Model/generate.html', '1', '1439966334');
INSERT INTO `onethink_action_log` VALUES ('27', '8', '1', '454105574', 'attribute', '56', '操作url：/admin.php?s=/Model/generate.html', '1', '1439966334');
INSERT INTO `onethink_action_log` VALUES ('28', '7', '1', '454105574', 'model', '7', '操作url：/admin.php?s=/Model/update.html', '1', '1439966382');
INSERT INTO `onethink_action_log` VALUES ('29', '8', '1', '454105574', 'attribute', '56', '操作url：/admin.php?s=/Attribute/update.html', '1', '1439966398');
INSERT INTO `onethink_action_log` VALUES ('30', '8', '1', '454105574', 'attribute', '57', '操作url：/admin.php?s=/Attribute/update.html', '1', '1439966425');
INSERT INTO `onethink_action_log` VALUES ('31', '1', '1', '454105574', 'member', '1', 'admin在2015-08-20 11:06登录了后台', '1', '1440039981');
INSERT INTO `onethink_action_log` VALUES ('32', '1', '1', '454105574', 'member', '1', 'admin在2015-08-20 11:18登录了后台', '1', '1440040703');
INSERT INTO `onethink_action_log` VALUES ('33', '1', '1', '454105574', 'member', '1', 'admin在2015-08-21 09:47登录了后台', '1', '1440121662');
INSERT INTO `onethink_action_log` VALUES ('34', '11', '1', '454105574', 'category', '5', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1440125226');
INSERT INTO `onethink_action_log` VALUES ('35', '1', '1', '454105574', 'member', '1', 'admin在2015-08-21 14:55登录了后台', '1', '1440140145');
INSERT INTO `onethink_action_log` VALUES ('36', '1', '2', '454105574', 'member', '2', 'canohparm在2015-08-21 14:59登录了后台', '1', '1440140378');
INSERT INTO `onethink_action_log` VALUES ('37', '1', '2', '454105574', 'member', '2', 'canohparm在2015-08-21 15:05登录了后台', '1', '1440140701');
INSERT INTO `onethink_action_log` VALUES ('38', '1', '1', '454105574', 'member', '1', 'admin在2015-08-21 15:10登录了后台', '1', '1440141050');
INSERT INTO `onethink_action_log` VALUES ('39', '1', '2', '454105574', 'member', '2', 'canohparm在2015-08-21 15:11登录了后台', '1', '1440141086');
INSERT INTO `onethink_action_log` VALUES ('40', '1', '1', '454105574', 'member', '1', 'admin在2015-08-21 15:38登录了后台', '1', '1440142683');
INSERT INTO `onethink_action_log` VALUES ('41', '1', '2', '454105574', 'member', '2', 'canohparm在2015-08-21 15:45登录了后台', '1', '1440143152');
INSERT INTO `onethink_action_log` VALUES ('42', '1', '1', '454105574', 'member', '1', 'admin在2015-08-21 17:09登录了后台', '1', '1440148177');
INSERT INTO `onethink_action_log` VALUES ('43', '1', '1', '454105574', 'member', '1', 'admin在2015-08-24 10:16登录了后台', '1', '1440382582');
INSERT INTO `onethink_action_log` VALUES ('44', '1', '1', '454105574', 'member', '1', 'admin在2015-08-24 17:16登录了后台', '1', '1440407802');
INSERT INTO `onethink_action_log` VALUES ('45', '1', '2', '454105574', 'member', '2', 'canohparm在2015-08-28 11:28登录了后台', '1', '1440732516');
INSERT INTO `onethink_action_log` VALUES ('46', '1', '1', '454105574', 'member', '1', 'admin在2015-08-28 17:22登录了后台', '1', '1440753741');
INSERT INTO `onethink_action_log` VALUES ('47', '1', '2', '454105574', 'member', '2', 'canohparm在2015-08-28 17:25登录了后台', '1', '1440753923');
INSERT INTO `onethink_action_log` VALUES ('48', '11', '2', '454105574', 'category', '11', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1440754017');
INSERT INTO `onethink_action_log` VALUES ('49', '11', '2', '454105574', 'category', '12', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1440754365');
INSERT INTO `onethink_action_log` VALUES ('50', '11', '2', '454105574', 'category', '11', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1440754857');
INSERT INTO `onethink_action_log` VALUES ('51', '11', '2', '454105574', 'category', '13', '操作url：/admin.php?s=/Profile/cate/cmethod/update.html', '1', '1440754985');
INSERT INTO `onethink_action_log` VALUES ('52', '1', '2', '454105574', 'member', '2', 'canohparm在2015-08-31 09:36登录了后台', '1', '1440984977');
INSERT INTO `onethink_action_log` VALUES ('53', '1', '1', '454105574', 'member', '1', 'admin在2015-08-31 09:40登录了后台', '1', '1440985221');

-- -----------------------------
-- Table structure for `onethink_addons`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_addons`;
CREATE TABLE `onethink_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `onethink_addons`
-- -----------------------------
INSERT INTO `onethink_addons` VALUES ('15', 'EditorForAdmin', '后台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"500px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1383126253', '0');
INSERT INTO `onethink_addons` VALUES ('2', 'SiteStat', '站点统计信息', '统计站点的基础信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"1\",\"display\":\"1\",\"status\":\"0\"}', 'thinkphp', '0.1', '1379512015', '0');
INSERT INTO `onethink_addons` VALUES ('3', 'DevTeam', '开发团队信息', '开发团队成员信息', '1', '{\"title\":\"OneThink\\u5f00\\u53d1\\u56e2\\u961f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512022', '0');
INSERT INTO `onethink_addons` VALUES ('4', 'SystemInfo', '系统环境信息', '用于显示一些服务器的信息', '1', '{\"title\":\"\\u7cfb\\u7edf\\u4fe1\\u606f\",\"width\":\"2\",\"display\":\"1\"}', 'thinkphp', '0.1', '1379512036', '0');
INSERT INTO `onethink_addons` VALUES ('5', 'Editor', '前台编辑器', '用于增强整站长文本的输入和显示', '1', '{\"editor_type\":\"2\",\"editor_wysiwyg\":\"1\",\"editor_height\":\"300px\",\"editor_resize_type\":\"1\"}', 'thinkphp', '0.1', '1379830910', '0');
INSERT INTO `onethink_addons` VALUES ('6', 'Attachment', '附件', '用于文档模型上传附件', '1', 'null', 'thinkphp', '0.1', '1379842319', '1');
INSERT INTO `onethink_addons` VALUES ('9', 'SocialComment', '通用社交化评论', '集成了各种社交化评论插件，轻松集成到系统中。', '1', '{\"comment_type\":\"1\",\"comment_uid_youyan\":\"\",\"comment_short_name_duoshuo\":\"\",\"comment_data_list_duoshuo\":\"\"}', 'thinkphp', '0.1', '1380273962', '0');
INSERT INTO `onethink_addons` VALUES ('16', 'Focus', '焦点图', '焦点图', '1', 'null', '凡人', '0.1', '1439966569', '1');

-- -----------------------------
-- Table structure for `onethink_attachment`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attachment`;
CREATE TABLE `onethink_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '附件显示名',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件类型',
  `source` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '资源ID',
  `record_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联记录ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '附件大小',
  `dir` int(12) unsigned NOT NULL DEFAULT '0' COMMENT '上级目录ID',
  `sort` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `idx_record_status` (`record_id`,`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='附件表';


-- -----------------------------
-- Table structure for `onethink_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_attribute`;
CREATE TABLE `onethink_attribute` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '字段名',
  `title` varchar(100) NOT NULL DEFAULT '' COMMENT '字段注释',
  `field` varchar(100) NOT NULL DEFAULT '' COMMENT '字段定义',
  `type` varchar(20) NOT NULL DEFAULT '' COMMENT '数据类型',
  `value` varchar(100) NOT NULL DEFAULT '' COMMENT '字段默认值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '备注',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否显示',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '参数',
  `model_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '模型id',
  `is_must` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否必填',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `update_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `validate_rule` varchar(255) NOT NULL DEFAULT '',
  `validate_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `error_info` varchar(100) NOT NULL DEFAULT '',
  `validate_type` varchar(25) NOT NULL DEFAULT '',
  `auto_rule` varchar(100) NOT NULL DEFAULT '',
  `auto_time` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `auto_type` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `model_id` (`model_id`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=utf8 COMMENT='模型属性表';

-- -----------------------------
-- Records of `onethink_attribute`
-- -----------------------------
INSERT INTO `onethink_attribute` VALUES ('1', 'uid', '用户ID', 'int(10) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1384508362', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('2', 'name', '标识', 'char(40) NOT NULL ', 'string', '', '同一根节点下标识不重复', '1', '', '1', '0', '1', '1383894743', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('3', 'title', '标题', 'char(80) NOT NULL ', 'string', '', '文档标题', '1', '', '1', '0', '1', '1383894778', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('4', 'category_id', '所属分类', 'int(10) unsigned NOT NULL ', 'string', '', '', '0', '', '1', '0', '1', '1384508336', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('5', 'description', '描述', 'char(255) NOT NULL ', 'textarea', '', '', '1', '', '1', '0', '1', '1439956017', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('6', 'root', '根节点', 'int(10) unsigned NOT NULL ', 'num', '0', '该文档的顶级文档编号', '0', '', '1', '0', '1', '1384508323', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('7', 'pid', '所属ID', 'int(10) unsigned NOT NULL ', 'num', '0', '父文档编号', '0', '', '1', '0', '1', '1384508543', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('8', 'model_id', '内容模型ID', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '该文档所对应的模型', '0', '', '1', '0', '1', '1384508350', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('9', 'type', '内容类型', 'tinyint(3) unsigned NOT NULL ', 'select', '2', '', '1', '1:目录\r\n2:主题\r\n3:段落', '1', '0', '1', '1384511157', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('10', 'position', '推荐位', 'smallint(5) unsigned NOT NULL ', 'checkbox', '0', '多个推荐则将其推荐值相加', '1', '[DOCUMENT_POSITION]', '1', '0', '1', '1383895640', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('11', 'link_id', '外链', 'int(10) unsigned NOT NULL ', 'num', '0', '0-非外链，大于0-外链ID,需要函数进行链接与编号的转换', '1', '', '1', '0', '1', '1383895757', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('12', 'cover_id', '封面', 'int(10) unsigned NOT NULL ', 'picture', '0', '0-无封面，大于0-封面图片ID，需要函数处理', '1', '', '1', '0', '1', '1384147827', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('13', 'display', '可见性', 'tinyint(3) unsigned NOT NULL ', 'radio', '1', '', '1', '0:不可见\r\n1:所有人可见', '1', '0', '1', '1386662271', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('14', 'deadline', '截至时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '0-永久有效', '1', '', '1', '0', '1', '1387163248', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('15', 'attach', '附件数量', 'tinyint(3) unsigned NOT NULL ', 'num', '0', '', '0', '', '1', '0', '1', '1387260355', '1383891233', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('16', 'view', '浏览量', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895835', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('17', 'comment', '评论数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '1', '0', '1', '1383895846', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('18', 'extend', '扩展统计字段', 'int(10) unsigned NOT NULL ', 'num', '0', '根据需求自行使用', '0', '', '1', '0', '1', '1384508264', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('19', 'level', '优先级', 'int(10) unsigned NOT NULL ', 'num', '0', '越高排序越靠前', '1', '', '1', '0', '1', '1383895894', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('20', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '1', '', '1', '0', '1', '1383895903', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('21', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'datetime', '0', '', '0', '', '1', '0', '1', '1384508277', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('22', 'status', '数据状态', 'tinyint(4) NOT NULL ', 'radio', '0', '', '0', '-1:删除\r\n0:禁用\r\n1:正常\r\n2:待审核\r\n3:草稿', '1', '0', '1', '1384508496', '1383891233', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('23', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '2', '0', '1', '1384511049', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('24', 'content', '文章内容', 'text NOT NULL ', 'editor', '', '', '1', '', '2', '0', '1', '1383896225', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('25', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '参照display方法参数的定义', '1', '', '2', '0', '1', '1383896190', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('26', 'bookmark', '收藏数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '2', '0', '1', '1383896103', '1383891243', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('27', 'parse', '内容解析类型', 'tinyint(3) unsigned NOT NULL ', 'select', '0', '', '0', '0:html\r\n1:ubb\r\n2:markdown', '3', '0', '1', '1387260461', '1383891252', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('28', 'content', '下载详细描述', 'text NOT NULL ', 'editor', '', '', '1', '', '3', '0', '1', '1383896438', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('29', 'template', '详情页显示模板', 'varchar(100) NOT NULL ', 'string', '', '', '1', '', '3', '0', '1', '1383896429', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('30', 'file_id', '文件ID', 'int(10) unsigned NOT NULL ', 'file', '0', '需要函数处理', '1', '', '3', '0', '1', '1383896415', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('31', 'download', '下载次数', 'int(10) unsigned NOT NULL ', 'num', '0', '', '1', '', '3', '0', '1', '1383896380', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('32', 'size', '文件大小', 'bigint(20) unsigned NOT NULL ', 'num', '0', '单位bit', '1', '', '3', '0', '1', '1383896371', '1383891252', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('34', 'domain', '域名', 'varchar(20) NOT NULL ', 'string', '', '', '1', '', '4', '0', '1', '1438139623', '1438139623', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('35', 'manage', '管理员', 'int(10) unsigned NOT NULL ', 'string', '', '', '1', '', '4', '0', '1', '1438139623', '1438139623', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('36', 'status', '状态', 'char(50) NOT NULL ', 'select', '', '', '1', '0:关闭\r\n1:开启', '4', '0', '1', '1438139707', '1438139623', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('37', 'title', 'title', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '4', '0', '1', '1438159285', '1438159285', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('38', 'description', 'description', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '4', '0', '1', '1438159303', '1438159303', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('39', 'keywords', 'keywords', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '4', '0', '1', '1438159315', '1438159315', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('40', 'theme', '模板', 'varchar(100) NOT NULL', 'string', '', '', '1', '', '4', '0', '1', '1438591632', '1438159338', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('41', 'content', '内容', 'text NOT NULL', 'editor', '', '', '1', '', '5', '0', '1', '1438739627', '1438739627', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('43', 'config', '站点设置', 'text NOT NULL', 'textarea', '', '', '1', '', '4', '0', '1', '1438754808', '1438754808', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('44', 'keywords', '关键词', 'varchar(255) NOT NULL', 'string', '', '', '1', '', '1', '0', '1', '1438915393', '1438915393', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('45', 'content', '详情', 'text NOT NULL', 'editor', '', '', '1', '', '6', '0', '1', '1439955123', '1439955123', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('46', 'cas', 'cas', 'varchar(25) NOT NULL', 'string', '', '', '1', '', '6', '0', '1', '1439955203', '1439955203', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('47', 'spec', '规格', 'varchar(25) NOT NULL', 'string', '', '', '1', '', '6', '0', '1', '1439955265', '1439955265', '', '3', '', 'regex', '', '3', 'function');
INSERT INTO `onethink_attribute` VALUES ('48', 'pid', '上级频道ID', 'int(10) unsigned NOT NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1439966334', '1439966334', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('49', 'title', '频道标题', 'char(30) NOT NULL ', 'string', '', '', '1', '', '7', '0', '1', '1439966334', '1439966334', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('50', 'url', '频道连接', 'char(100) NOT NULL ', 'string', '', '', '1', '', '7', '0', '1', '1439966334', '1439966334', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('51', 'sort', '导航排序', 'int(10) unsigned NOT NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1439966334', '1439966334', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('52', 'create_time', '创建时间', 'int(10) unsigned NOT NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1439966334', '1439966334', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('53', 'update_time', '更新时间', 'int(10) unsigned NOT NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1439966334', '1439966334', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('54', 'status', '状态', 'tinyint(4) NOT NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1439966334', '1439966334', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('55', 'target', '新窗口打开', 'tinyint(2) unsigned NOT NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1439966334', '1439966334', '', '0', '', '', '', '0', '');
INSERT INTO `onethink_attribute` VALUES ('56', 'site_id', '所属站点', 'int(10) unsigned NOT NULL ', 'string', '0', '', '1', '', '7', '0', '1', '1439966398', '1439966334', '', '0', '', 'regex', '', '0', 'function');
INSERT INTO `onethink_attribute` VALUES ('57', 'name', '英文名', 'varchar(25) NOT NULL', 'string', '', '', '1', '', '7', '0', '1', '1439966425', '1439966425', '', '3', '', 'regex', '', '3', 'function');

-- -----------------------------
-- Table structure for `onethink_auth_extend`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_extend`;
CREATE TABLE `onethink_auth_extend` (
  `group_id` mediumint(10) unsigned NOT NULL COMMENT '用户id',
  `extend_id` mediumint(8) unsigned NOT NULL COMMENT '扩展表中数据的id',
  `type` tinyint(1) unsigned NOT NULL COMMENT '扩展类型标识 1:栏目分类权限;2:模型权限',
  UNIQUE KEY `group_extend_type` (`group_id`,`extend_id`,`type`),
  KEY `uid` (`group_id`),
  KEY `group_id` (`extend_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户组与分类的对应关系表';

-- -----------------------------
-- Records of `onethink_auth_extend`
-- -----------------------------
INSERT INTO `onethink_auth_extend` VALUES ('1', '1', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '2', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '2', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '3', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '3', '2');
INSERT INTO `onethink_auth_extend` VALUES ('1', '4', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '5', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '6', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '7', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '8', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '9', '1');
INSERT INTO `onethink_auth_extend` VALUES ('1', '10', '1');

-- -----------------------------
-- Table structure for `onethink_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group`;
CREATE TABLE `onethink_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户组id,自增主键',
  `module` varchar(20) NOT NULL DEFAULT '' COMMENT '用户组所属模块',
  `type` tinyint(4) NOT NULL DEFAULT '0' COMMENT '组类型',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '用户组中文名称',
  `description` varchar(80) NOT NULL DEFAULT '' COMMENT '描述信息',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '用户组状态：为1正常，为0禁用,-1为删除',
  `rules` varchar(500) NOT NULL DEFAULT '' COMMENT '用户组拥有的规则id，多个规则 , 隔开',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_group`
-- -----------------------------
INSERT INTO `onethink_auth_group` VALUES ('1', 'admin', '1', '网站内容管理', '', '1', '1,2,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,81,82,83,84,86,87,88,89,90,91,92,93,94,95,100,102,103,220,221,222,223,224,226');
INSERT INTO `onethink_auth_group` VALUES ('2', 'admin', '1', '测试用户', '测试用户', '1', '1,2,5,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,79,80,82,83,84,88,89,90,91,92,93,96,97,100,102,103,195');

-- -----------------------------
-- Table structure for `onethink_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_group_access`;
CREATE TABLE `onethink_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `group_id` mediumint(8) unsigned NOT NULL COMMENT '用户组id',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_group_access`
-- -----------------------------
INSERT INTO `onethink_auth_group_access` VALUES ('2', '1');

-- -----------------------------
-- Table structure for `onethink_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_auth_rule`;
CREATE TABLE `onethink_auth_rule` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT COMMENT '规则id,自增主键',
  `module` varchar(20) NOT NULL COMMENT '规则所属module',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1-url;2-主菜单',
  `name` char(80) NOT NULL DEFAULT '' COMMENT '规则唯一英文标识',
  `title` char(20) NOT NULL DEFAULT '' COMMENT '规则中文描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否有效(0:无效,1:有效)',
  `condition` varchar(300) NOT NULL DEFAULT '' COMMENT '规则附加条件',
  PRIMARY KEY (`id`),
  KEY `module` (`module`,`status`,`type`)
) ENGINE=MyISAM AUTO_INCREMENT=227 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_auth_rule`
-- -----------------------------
INSERT INTO `onethink_auth_rule` VALUES ('1', 'admin', '2', 'Admin/Index/index', '首页', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('2', 'admin', '2', 'Admin/Article/index', '内容', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('3', 'admin', '2', 'Admin/User/index', '用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('4', 'admin', '2', 'Admin/Addons/index', '扩展', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('5', 'admin', '2', 'Admin/Config/group', '系统', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('7', 'admin', '1', 'Admin/article/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('8', 'admin', '1', 'Admin/article/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('9', 'admin', '1', 'Admin/article/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('10', 'admin', '1', 'Admin/article/update', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('11', 'admin', '1', 'Admin/article/autoSave', '保存草稿', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('12', 'admin', '1', 'Admin/article/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('13', 'admin', '1', 'Admin/article/copy', '复制', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('14', 'admin', '1', 'Admin/article/paste', '粘贴', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('15', 'admin', '1', 'Admin/article/permit', '还原', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('16', 'admin', '1', 'Admin/article/clear', '清空', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('17', 'admin', '1', 'Admin/Article/examine', '审核列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('18', 'admin', '1', 'Admin/article/recycle', '回收站', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('19', 'admin', '1', 'Admin/User/addaction', '新增用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('20', 'admin', '1', 'Admin/User/editaction', '编辑用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('21', 'admin', '1', 'Admin/User/saveAction', '保存用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('22', 'admin', '1', 'Admin/User/setStatus', '变更行为状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('23', 'admin', '1', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('24', 'admin', '1', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('25', 'admin', '1', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('26', 'admin', '1', 'Admin/User/index', '用户信息', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('27', 'admin', '1', 'Admin/User/action', '用户行为', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('28', 'admin', '1', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('29', 'admin', '1', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('30', 'admin', '1', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('31', 'admin', '1', 'Admin/AuthManager/createGroup', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('32', 'admin', '1', 'Admin/AuthManager/editGroup', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('33', 'admin', '1', 'Admin/AuthManager/writeGroup', '保存用户组', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('34', 'admin', '1', 'Admin/AuthManager/group', '授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('35', 'admin', '1', 'Admin/AuthManager/access', '访问授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('36', 'admin', '1', 'Admin/AuthManager/user', '成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('37', 'admin', '1', 'Admin/AuthManager/removeFromGroup', '解除授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('38', 'admin', '1', 'Admin/AuthManager/addToGroup', '保存成员授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('39', 'admin', '1', 'Admin/AuthManager/category', '分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('40', 'admin', '1', 'Admin/AuthManager/addToCategory', '保存分类授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('41', 'admin', '1', 'Admin/AuthManager/index', '权限管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('42', 'admin', '1', 'Admin/Addons/create', '创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('43', 'admin', '1', 'Admin/Addons/checkForm', '检测创建', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('44', 'admin', '1', 'Admin/Addons/preview', '预览', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('45', 'admin', '1', 'Admin/Addons/build', '快速生成插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('46', 'admin', '1', 'Admin/Addons/config', '设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('47', 'admin', '1', 'Admin/Addons/disable', '禁用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('48', 'admin', '1', 'Admin/Addons/enable', '启用', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('49', 'admin', '1', 'Admin/Addons/install', '安装', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('50', 'admin', '1', 'Admin/Addons/uninstall', '卸载', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('51', 'admin', '1', 'Admin/Addons/saveconfig', '更新配置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('52', 'admin', '1', 'Admin/Addons/adminList', '插件后台列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('53', 'admin', '1', 'Admin/Addons/execute', 'URL方式访问插件', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('54', 'admin', '1', 'Admin/Addons/index', '插件管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('55', 'admin', '1', 'Admin/Addons/hooks', '钩子管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('56', 'admin', '1', 'Admin/model/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('57', 'admin', '1', 'Admin/model/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('58', 'admin', '1', 'Admin/model/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('59', 'admin', '1', 'Admin/model/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('60', 'admin', '1', 'Admin/Model/index', '模型管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('61', 'admin', '1', 'Admin/Config/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('62', 'admin', '1', 'Admin/Config/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('63', 'admin', '1', 'Admin/Config/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('64', 'admin', '1', 'Admin/Config/save', '保存', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('65', 'admin', '1', 'Admin/Config/group', '网站设置', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('66', 'admin', '1', 'Admin/Config/index', '配置管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('67', 'admin', '1', 'Admin/Channel/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('68', 'admin', '1', 'Admin/Channel/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('69', 'admin', '1', 'Admin/Channel/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('70', 'admin', '1', 'Admin/Channel/index', '导航管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('71', 'admin', '1', 'Admin/Category/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('72', 'admin', '1', 'Admin/Category/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('73', 'admin', '1', 'Admin/Category/remove', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('74', 'admin', '1', 'Admin/Category/index', '分类管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('75', 'admin', '1', 'Admin/file/upload', '上传控件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('76', 'admin', '1', 'Admin/file/uploadPicture', '上传图片', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('77', 'admin', '1', 'Admin/file/download', '下载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('94', 'admin', '1', 'Admin/AuthManager/modelauth', '模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('79', 'admin', '1', 'Admin/article/batchOperate', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('80', 'admin', '1', 'Admin/Database/index?type=export', '备份数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('81', 'admin', '1', 'Admin/Database/index?type=import', '还原数据库', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('82', 'admin', '1', 'Admin/Database/export', '备份', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('83', 'admin', '1', 'Admin/Database/optimize', '优化表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('84', 'admin', '1', 'Admin/Database/repair', '修复表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('86', 'admin', '1', 'Admin/Database/import', '恢复', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('87', 'admin', '1', 'Admin/Database/del', '删除', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('88', 'admin', '1', 'Admin/User/add', '新增用户', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('89', 'admin', '1', 'Admin/Attribute/index', '属性管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('90', 'admin', '1', 'Admin/Attribute/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('91', 'admin', '1', 'Admin/Attribute/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('92', 'admin', '1', 'Admin/Attribute/setStatus', '改变状态', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('93', 'admin', '1', 'Admin/Attribute/update', '保存数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('95', 'admin', '1', 'Admin/AuthManager/addToModel', '保存模型授权', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('96', 'admin', '1', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('97', 'admin', '1', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('98', 'admin', '1', 'Admin/Config/menu', '后台菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('99', 'admin', '1', 'Admin/Article/mydocument', '内容', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('100', 'admin', '1', 'Admin/Menu/index', '菜单管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('101', 'admin', '1', 'Admin/other', '其他', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('102', 'admin', '1', 'Admin/Menu/add', '新增', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('103', 'admin', '1', 'Admin/Menu/edit', '编辑', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('104', 'admin', '1', 'Admin/Think/lists?model=article', '文章管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('105', 'admin', '1', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('106', 'admin', '1', 'Admin/Think/lists?model=config', '配置管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('107', 'admin', '1', 'Admin/Action/actionlog', '行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('108', 'admin', '1', 'Admin/User/updatePassword', '修改密码', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('109', 'admin', '1', 'Admin/User/updateNickname', '修改昵称', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('110', 'admin', '1', 'Admin/action/edit', '查看行为日志', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('205', 'admin', '1', 'Admin/think/add', '新增数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('111', 'admin', '2', 'Admin/article/index', '文档列表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('112', 'admin', '2', 'Admin/article/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('113', 'admin', '2', 'Admin/article/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('114', 'admin', '2', 'Admin/article/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('115', 'admin', '2', 'Admin/article/update', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('116', 'admin', '2', 'Admin/article/autoSave', '保存草稿', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('117', 'admin', '2', 'Admin/article/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('118', 'admin', '2', 'Admin/article/copy', '复制', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('119', 'admin', '2', 'Admin/article/paste', '粘贴', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('120', 'admin', '2', 'Admin/article/batchOperate', '导入', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('121', 'admin', '2', 'Admin/article/recycle', '回收站', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('122', 'admin', '2', 'Admin/article/permit', '还原', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('123', 'admin', '2', 'Admin/article/clear', '清空', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('124', 'admin', '2', 'Admin/User/add', '新增用户', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('125', 'admin', '2', 'Admin/User/action', '用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('126', 'admin', '2', 'Admin/User/addAction', '新增用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('127', 'admin', '2', 'Admin/User/editAction', '编辑用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('128', 'admin', '2', 'Admin/User/saveAction', '保存用户行为', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('129', 'admin', '2', 'Admin/User/setStatus', '变更行为状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('130', 'admin', '2', 'Admin/User/changeStatus?method=forbidUser', '禁用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('131', 'admin', '2', 'Admin/User/changeStatus?method=resumeUser', '启用会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('132', 'admin', '2', 'Admin/User/changeStatus?method=deleteUser', '删除会员', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('133', 'admin', '2', 'Admin/AuthManager/index', '权限管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('134', 'admin', '2', 'Admin/AuthManager/changeStatus?method=deleteGroup', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('135', 'admin', '2', 'Admin/AuthManager/changeStatus?method=forbidGroup', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('136', 'admin', '2', 'Admin/AuthManager/changeStatus?method=resumeGroup', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('137', 'admin', '2', 'Admin/AuthManager/createGroup', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('138', 'admin', '2', 'Admin/AuthManager/editGroup', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('139', 'admin', '2', 'Admin/AuthManager/writeGroup', '保存用户组', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('140', 'admin', '2', 'Admin/AuthManager/group', '授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('141', 'admin', '2', 'Admin/AuthManager/access', '访问授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('142', 'admin', '2', 'Admin/AuthManager/user', '成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('143', 'admin', '2', 'Admin/AuthManager/removeFromGroup', '解除授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('144', 'admin', '2', 'Admin/AuthManager/addToGroup', '保存成员授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('145', 'admin', '2', 'Admin/AuthManager/category', '分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('146', 'admin', '2', 'Admin/AuthManager/addToCategory', '保存分类授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('147', 'admin', '2', 'Admin/AuthManager/modelauth', '模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('148', 'admin', '2', 'Admin/AuthManager/addToModel', '保存模型授权', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('149', 'admin', '2', 'Admin/Addons/create', '创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('150', 'admin', '2', 'Admin/Addons/checkForm', '检测创建', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('151', 'admin', '2', 'Admin/Addons/preview', '预览', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('152', 'admin', '2', 'Admin/Addons/build', '快速生成插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('153', 'admin', '2', 'Admin/Addons/config', '设置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('154', 'admin', '2', 'Admin/Addons/disable', '禁用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('155', 'admin', '2', 'Admin/Addons/enable', '启用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('156', 'admin', '2', 'Admin/Addons/install', '安装', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('157', 'admin', '2', 'Admin/Addons/uninstall', '卸载', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('158', 'admin', '2', 'Admin/Addons/saveconfig', '更新配置', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('159', 'admin', '2', 'Admin/Addons/adminList', '插件后台列表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('160', 'admin', '2', 'Admin/Addons/execute', 'URL方式访问插件', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('161', 'admin', '2', 'Admin/Addons/hooks', '钩子管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('162', 'admin', '2', 'Admin/Model/index', '模型管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('163', 'admin', '2', 'Admin/model/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('164', 'admin', '2', 'Admin/model/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('165', 'admin', '2', 'Admin/model/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('166', 'admin', '2', 'Admin/model/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('167', 'admin', '2', 'Admin/Attribute/index', '属性管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('168', 'admin', '2', 'Admin/Attribute/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('169', 'admin', '2', 'Admin/Attribute/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('170', 'admin', '2', 'Admin/Attribute/setStatus', '改变状态', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('171', 'admin', '2', 'Admin/Attribute/update', '保存数据', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('172', 'admin', '2', 'Admin/Config/index', '配置管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('173', 'admin', '2', 'Admin/Config/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('174', 'admin', '2', 'Admin/Config/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('175', 'admin', '2', 'Admin/Config/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('176', 'admin', '2', 'Admin/Config/save', '保存', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('177', 'admin', '2', 'Admin/Menu/index', '菜单管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('178', 'admin', '2', 'Admin/Channel/index', '导航管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('179', 'admin', '2', 'Admin/Channel/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('180', 'admin', '2', 'Admin/Channel/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('181', 'admin', '2', 'Admin/Channel/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('182', 'admin', '2', 'Admin/Category/index', '分类管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('183', 'admin', '2', 'Admin/Category/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('184', 'admin', '2', 'Admin/Category/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('185', 'admin', '2', 'Admin/Category/remove', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('186', 'admin', '2', 'Admin/Category/move', '移动', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('187', 'admin', '2', 'Admin/Category/merge', '合并', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('188', 'admin', '2', 'Admin/Database/index?type=export', '备份数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('189', 'admin', '2', 'Admin/Database/export', '备份', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('190', 'admin', '2', 'Admin/Database/optimize', '优化表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('191', 'admin', '2', 'Admin/Database/repair', '修复表', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('192', 'admin', '2', 'Admin/Database/index?type=import', '还原数据库', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('193', 'admin', '2', 'Admin/Database/import', '恢复', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('194', 'admin', '2', 'Admin/Database/del', '删除', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('195', 'admin', '2', 'Admin/other', '其他', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('196', 'admin', '2', 'Admin/Menu/add', '新增', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('197', 'admin', '2', 'Admin/Menu/edit', '编辑', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('198', 'admin', '2', 'Admin/Think/lists?model=article', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('199', 'admin', '2', 'Admin/Think/lists?model=download', '下载管理', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('200', 'admin', '2', 'Admin/Think/lists?model=config', '应用', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('201', 'admin', '2', 'Admin/Action/actionlog', '行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('202', 'admin', '2', 'Admin/User/updatePassword', '修改密码', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('203', 'admin', '2', 'Admin/User/updateNickname', '修改昵称', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('204', 'admin', '2', 'Admin/action/edit', '查看行为日志', '-1', '');
INSERT INTO `onethink_auth_rule` VALUES ('206', 'admin', '1', 'Admin/think/edit', '编辑数据', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('207', 'admin', '1', 'Admin/Menu/import', '导入', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('208', 'admin', '1', 'Admin/Model/generate', '生成', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('209', 'admin', '1', 'Admin/Addons/addHook', '新增钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('210', 'admin', '1', 'Admin/Addons/edithook', '编辑钩子', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('211', 'admin', '1', 'Admin/Article/sort', '文档排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('212', 'admin', '1', 'Admin/Config/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('213', 'admin', '1', 'Admin/Menu/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('214', 'admin', '1', 'Admin/Channel/sort', '排序', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('215', 'admin', '1', 'Admin/Category/operate/type/move', '移动', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('216', 'admin', '1', 'Admin/Category/operate/type/merge', '合并', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('217', 'admin', '1', 'Admin/article/index', '文档列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('218', 'admin', '1', 'Admin/think/lists', '数据列表', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('219', 'admin', '1', 'Admin/SIte/temp', '我的站点', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('220', 'admin', '1', 'Admin/Profile/info', '我的资料', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('221', 'admin', '1', 'Admin/Profile/site', '我的站点', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('222', 'admin', '1', 'Admin/Profile/cate', '栏目管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('223', 'admin', '1', 'Admin/Profile/article', '文章管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('224', 'admin', '1', 'Admin/Profile/channel', '导航管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('225', 'admin', '2', 'Admin/Site/index', '站点管理', '1', '');
INSERT INTO `onethink_auth_rule` VALUES ('226', 'admin', '2', 'Admin/Profile/index', '个人中心', '1', '');

-- -----------------------------
-- Table structure for `onethink_category`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_category`;
CREATE TABLE `onethink_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `name` varchar(30) NOT NULL COMMENT '标志',
  `title` varchar(50) NOT NULL COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `list_row` tinyint(3) unsigned NOT NULL DEFAULT '10' COMMENT '列表每页行数',
  `meta_title` varchar(50) NOT NULL DEFAULT '' COMMENT 'SEO的网页标题',
  `keywords` varchar(255) NOT NULL DEFAULT '' COMMENT '关键字',
  `description` varchar(255) NOT NULL DEFAULT '' COMMENT '描述',
  `template_index` varchar(100) NOT NULL DEFAULT '' COMMENT '频道页模板',
  `template_lists` varchar(100) NOT NULL DEFAULT '' COMMENT '列表页模板',
  `template_detail` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑页模板',
  `model` varchar(100) NOT NULL DEFAULT '' COMMENT '列表绑定模型',
  `model_sub` varchar(100) NOT NULL DEFAULT '' COMMENT '子文档绑定模型',
  `type` varchar(100) NOT NULL DEFAULT '' COMMENT '允许发布的内容类型',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `allow_publish` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许发布内容',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '可见性',
  `reply` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否允许回复',
  `check` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '发布的文章是否需要审核',
  `reply_model` varchar(100) NOT NULL DEFAULT '',
  `extend` text COMMENT '扩展设置',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `icon` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类图标',
  `groups` varchar(255) NOT NULL DEFAULT '' COMMENT '分组定义',
  `site_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属站点',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='分类表';

-- -----------------------------
-- Records of `onethink_category`
-- -----------------------------
INSERT INTO `onethink_category` VALUES ('2', 'about', '公司简介', '0', '1', '10', '公司简介', '公司简介', '公司简介', '', '', '', '', '5', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1439955409', '1439955409', '1', '0', '', '1');
INSERT INTO `onethink_category` VALUES ('3', 'news', '行业动态', '0', '2', '10', '行业动态', '行业动态', '行业动态', '', '', '', '', '2', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1439955431', '1439955431', '1', '0', '', '1');
INSERT INTO `onethink_category` VALUES ('4', 'product', '产品列表', '0', '3', '10', '产品列表', '产品列表', '产品列表', '', '', '', '', '6', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1439955456', '1439955456', '1', '0', '', '1');
INSERT INTO `onethink_category` VALUES ('5', 'technology', '科研技术', '0', '4', '10', '科研技术', '科研技术', '科研技术', 'Article/article/index_tech', '', 'Article/article/detail_tech', '', '2', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1439955488', '1440125226', '1', '0', '', '1');
INSERT INTO `onethink_category` VALUES ('6', 'sales', '销售网络', '0', '6', '10', '销售网络', '销售网络', '销售网络', '', '', '', '', '5', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1439955510', '1439955510', '1', '0', '', '1');
INSERT INTO `onethink_category` VALUES ('7', 'jobs', '人员招聘', '0', '7', '10', '人员招聘', '人员招聘', '人员招聘', '', '', '', '', '5', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1439955536', '1439955536', '1', '0', '', '1');
INSERT INTO `onethink_category` VALUES ('8', 'culture', '企业文化', '0', '9', '10', '企业文化', '企业文化', '企业文化', '', '', '', '', '5', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1439955566', '1439955566', '1', '0', '', '1');
INSERT INTO `onethink_category` VALUES ('9', 'academic', '学术交流', '0', '5', '10', '学术交流', '学术交流', '学术交流', '', '', '', '', '2', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1439955594', '1439955594', '1', '0', '', '1');
INSERT INTO `onethink_category` VALUES ('10', 'contact', '联系方式', '0', '8', '10', '联系方式', '联系方式', '联系方式', '', '', '', '', '5', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1439957548', '1439957548', '1', '0', '', '1');
INSERT INTO `onethink_category` VALUES ('11', 'aboutus', 'About', '0', '0', '10', 'About', 'About', 'About', '', '', '', '', '5', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1440754017', '1440754857', '1', '0', '', '2');
INSERT INTO `onethink_category` VALUES ('12', 'product_en', 'Product', '0', '0', '10', 'Product', 'Product', 'Product', '', '', '', '', '6', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1440754365', '1440754365', '1', '0', '', '2');
INSERT INTO `onethink_category` VALUES ('13', 'contactus', 'Contact', '0', '0', '10', 'Contact', 'Contact', 'Contact', '', '', '', '', '5', '', '2,1,3', '0', '1', '1', '1', '0', '', '', '1440754985', '1440754985', '1', '0', '', '2');

-- -----------------------------
-- Table structure for `onethink_channel`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_channel`;
CREATE TABLE `onethink_channel` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '频道ID',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级频道ID',
  `title` char(30) NOT NULL COMMENT '频道标题',
  `url` char(100) NOT NULL COMMENT '频道连接',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '导航排序',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `target` tinyint(2) unsigned NOT NULL DEFAULT '0' COMMENT '新窗口打开',
  `site_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属站点',
  `name` varchar(25) NOT NULL COMMENT '英文名',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_channel`
-- -----------------------------
INSERT INTO `onethink_channel` VALUES ('1', '0', '首页', '/', '1', '1379475111', '1439966442', '1', '0', '1', 'Home');
INSERT INTO `onethink_channel` VALUES ('2', '0', '公司简介', 'cate/about', '2', '1439956979', '1439966483', '1', '0', '1', 'About');
INSERT INTO `onethink_channel` VALUES ('3', '0', '技术科研', 'cate/technology', '5', '1439957001', '1439966495', '1', '0', '1', 'Technology');
INSERT INTO `onethink_channel` VALUES ('4', '0', '人员招聘', 'cate/jobs', '7', '1439957067', '1439966505', '1', '0', '1', 'Jobs');
INSERT INTO `onethink_channel` VALUES ('5', '0', '产品列表', 'cate/product', '4', '1439966166', '1439966472', '1', '0', '1', 'Products');
INSERT INTO `onethink_channel` VALUES ('6', '0', '行业动态', 'cate/news', '3', '1439966186', '1439966458', '1', '0', '1', 'News');
INSERT INTO `onethink_channel` VALUES ('7', '0', '销售网络', 'cate/sales', '6', '1439967505', '1439967505', '1', '0', '1', 'Sales');
INSERT INTO `onethink_channel` VALUES ('8', '0', '企业文化', 'cate/culture', '8', '1439967541', '1439967541', '0', '0', '1', 'Culture');
INSERT INTO `onethink_channel` VALUES ('9', '0', 'Home', '/', '0', '1440754900', '1440754900', '1', '0', '2', 'home');
INSERT INTO `onethink_channel` VALUES ('10', '0', 'About', 'cate/aboutus', '0', '1440754922', '1440754922', '1', '0', '2', 'About');
INSERT INTO `onethink_channel` VALUES ('11', '0', 'ContactUs', 'cate/contactus', '0', '1440755361', '1440755361', '1', '0', '2', 'contactus');

-- -----------------------------
-- Table structure for `onethink_config`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_config`;
CREATE TABLE `onethink_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `group` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL DEFAULT '' COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `group` (`group`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_config`
-- -----------------------------
INSERT INTO `onethink_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', 'OneThink内容管理框架', '0');
INSERT INTO `onethink_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'OneThink内容管理框架', '1');
INSERT INTO `onethink_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'ThinkPHP,OneThink', '8');
INSERT INTO `onethink_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举', '2');
INSERT INTO `onethink_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '9');
INSERT INTO `onethink_config` VALUES ('11', 'DOCUMENT_POSITION', '3', '文档推荐位', '2', '', '文档推荐位，推荐到多个位置KEY值相加即可', '1379053380', '1379235329', '1', '1:列表推荐\r\n2:频道推荐\r\n4:首页推荐', '3');
INSERT INTO `onethink_config` VALUES ('12', 'DOCUMENT_DISPLAY', '3', '文档可见性', '2', '', '文章可见性仅影响前台显示，后台不收影响', '1379056370', '1379235322', '1', '0:所有人可见\r\n1:仅注册会员可见\r\n2:仅管理员可见', '4');
INSERT INTO `onethink_config` VALUES ('13', 'COLOR_STYLE', '4', '后台色系', '1', 'default_color:默认\r\nblue_color:紫罗兰', '后台颜色风格', '1379122533', '1379235904', '1', 'default_color', '10');
INSERT INTO `onethink_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1384418383', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统', '4');
INSERT INTO `onethink_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `onethink_config` VALUES ('22', 'AUTH_CONFIG', '3', 'Auth配置', '4', '', '自定义Auth.class.php类配置', '1379409310', '1379409564', '1', 'AUTH_ON:1\r\nAUTH_TYPE:2', '8');
INSERT INTO `onethink_config` VALUES ('23', 'OPEN_DRAFTBOX', '4', '是否开启草稿功能', '2', '0:关闭草稿功能\r\n1:开启草稿功能\r\n', '新增文章时的草稿功能配置', '1379484332', '1379484591', '1', '1', '1');
INSERT INTO `onethink_config` VALUES ('24', 'DRAFT_AOTOSAVE_INTERVAL', '0', '自动保存草稿时间', '2', '', '自动保存草稿的时间间隔，单位：秒', '1379484574', '1386143323', '1', '60', '2');
INSERT INTO `onethink_config` VALUES ('25', 'LIST_ROWS', '0', '后台每页记录数', '2', '', '后台数据每页显示记录数', '1379503896', '1380427745', '1', '10', '10');
INSERT INTO `onethink_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `onethink_config` VALUES ('27', 'CODEMIRROR_THEME', '4', '预览插件的CodeMirror主题', '4', '3024-day:3024 day\r\n3024-night:3024 night\r\nambiance:ambiance\r\nbase16-dark:base16 dark\r\nbase16-light:base16 light\r\nblackboard:blackboard\r\ncobalt:cobalt\r\neclipse:eclipse\r\nelegant:elegant\r\nerlang-dark:erlang-dark\r\nlesser-dark:lesser-dark\r\nmidnight:midnight', '详情见CodeMirror官网', '1379814385', '1384740813', '1', 'ambiance', '3');
INSERT INTO `onethink_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `onethink_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `onethink_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `onethink_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `onethink_config` VALUES ('32', 'DEVELOP_MODE', '4', '开启开发者模式', '4', '0:关闭\r\n1:开启', '是否开启开发者模式', '1383105995', '1383291877', '1', '1', '11');
INSERT INTO `onethink_config` VALUES ('33', 'ALLOW_VISIT', '3', '不受限控制器方法', '0', '', '', '1386644047', '1386644741', '1', '0:article/draftbox\r\n1:article/mydocument\r\n2:Category/tree\r\n3:Index/verify\r\n4:file/upload\r\n5:file/download\r\n6:user/updatePassword\r\n7:user/updateNickname\r\n8:user/submitPassword\r\n9:user/submitNickname\r\n10:file/uploadpicture', '0');
INSERT INTO `onethink_config` VALUES ('34', 'DENY_VISIT', '3', '超管专限控制器方法', '0', '', '仅超级管理员可访问的控制器方法', '1386644141', '1386644659', '1', '0:Addons/addhook\r\n1:Addons/edithook\r\n2:Addons/delhook\r\n3:Addons/updateHook\r\n4:Admin/getMenus\r\n5:Admin/recordList\r\n6:AuthManager/updateRules\r\n7:AuthManager/tree', '0');
INSERT INTO `onethink_config` VALUES ('35', 'REPLY_LIST_ROWS', '0', '回复列表每页条数', '2', '', '', '1386645376', '1387178083', '1', '10', '0');
INSERT INTO `onethink_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `onethink_config` VALUES ('37', 'SHOW_PAGE_TRACE', '4', '是否显示页面Trace', '4', '0:关闭\r\n1:开启', '是否显示页面Trace信息', '1387165685', '1387165685', '1', '0', '1');

-- -----------------------------
-- Table structure for `onethink_document`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document`;
CREATE TABLE `onethink_document` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `name` char(40) NOT NULL DEFAULT '' COMMENT '标识',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '标题',
  `category_id` int(10) unsigned NOT NULL COMMENT '所属分类',
  `group_id` smallint(3) unsigned NOT NULL COMMENT '所属分组',
  `description` char(255) NOT NULL COMMENT '描述',
  `root` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '根节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '所属ID',
  `model_id` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容模型ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '2' COMMENT '内容类型',
  `position` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '推荐位',
  `link_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '外链',
  `cover_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '封面',
  `display` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '可见性',
  `deadline` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '截至时间',
  `attach` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '附件数量',
  `view` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `comment` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '扩展统计字段',
  `level` int(10) NOT NULL DEFAULT '0' COMMENT '优先级',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据状态',
  `keywords` varchar(255) NOT NULL COMMENT '关键词',
  PRIMARY KEY (`id`),
  KEY `idx_category_status` (`category_id`,`status`),
  KEY `idx_status_type_pid` (`status`,`uid`,`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COMMENT='文档模型基础表';

-- -----------------------------
-- Records of `onethink_document`
-- -----------------------------
INSERT INTO `onethink_document` VALUES ('2', '2', 'ResearchCenterOfChiralTechnologyNanjing', '新型手性技术研发中心（南京）', '5', '0', '新型手性技术研发中心于2014年入驻南京创新药物百家汇研发平台，百家汇依托先声药业强大的新药研发科研基础，组建了多个创新药物研发技术平台：抗体药物平台、生物评价平台、分析测试中心、实验动物中心、引进国内外知名CRO公司组成的CRO联盟，为入驻企业提供全方位的研发支持服务。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '33', '0', '0', '3', '1439955960', '1439956215', '1', '新型手性技术研发中心（南京），克里斯蒂安·山多夫');
INSERT INTO `onethink_document` VALUES ('3', '2', 'TongjiMedicalExperimentalPlatform', '励合-同济医学部联合实验平台（武汉）', '5', '0', '励合-同济医学部联合实验平台--------位于东湖国家自主创新示范区武汉生物技术研究院内，武汉生物技术研究院由湖北省委省政府整合武汉大学、华中科技大学、华中农业大学、中科院武汉分院、武汉凯迪控股等高校、科研院所、企业的优势资源组建而成', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '46', '0', '0', '2', '1439956538', '1439956538', '1', '励合-同济医学部联合实验平台（武汉）');
INSERT INTO `onethink_document` VALUES ('4', '2', 'TheIndustrialBase', '励合手性药物产业化基地（武汉）', '5', '0', '励合手性药物产业化基地（武汉）----位于武汉市东西湖区走马岭医药园内，建立了湖北省最大的手性药物研发及产业化基地。拥有国际一流的手性技术实验装备及人才。', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '26', '0', '0', '1', '1439956684', '1439956684', '1', '励合手性药物产业化基地（武汉）');
INSERT INTO `onethink_document` VALUES ('5', '2', 'companyInfo', '公司简介', '2', '0', '南京楷伦生物医药科技有限公司是一家专注于新型手性催化技术开发及，手性药物产业化研究，致力于为国内外制药企业，新药研发机构，科研院所，高校等提供国际领先，优质，经济的新型手性技术开发与手性药物制备一站式服务。', '0', '0', '5', '1', '0', '0', '0', '0', '1439956740', '0', '112', '0', '0', '0', '1439956740', '1440733598', '1', '南京楷伦生物医药科技有限公司，克里斯蒂安 ∙ 山多夫，新型手性技术研发');
INSERT INTO `onethink_document` VALUES ('6', '2', 'jobs', '招聘简章', '7', '0', '招聘', '0', '0', '5', '1', '0', '0', '0', '0', '1439956800', '0', '45', '0', '0', '0', '1439956800', '1439956936', '1', '招聘');
INSERT INTO `onethink_document` VALUES ('7', '2', 'contact', '联系方式', '10', '0', '联系方式', '0', '0', '5', '1', '0', '0', '0', '0', '1439957520', '0', '12', '0', '0', '0', '1439957520', '1440733777', '1', '联系方式');
INSERT INTO `onethink_document` VALUES ('8', '2', 'sales', '销售网络', '6', '0', '销售网络', '0', '0', '5', '1', '0', '0', '0', '0', '1440125280', '0', '27', '0', '0', '0', '1440125280', '1440125481', '1', '销售网络');
INSERT INTO `onethink_document` VALUES ('9', '2', '', '用手性技术为制药化学增添一抹“绿”', '3', '0', '', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '5', '0', '0', '0', '1440140777', '1440140777', '1', '');
INSERT INTO `onethink_document` VALUES ('10', '2', '', '手性技术中国现状：一流科研实力 VS 低水平产业化', '3', '0', '', '0', '0', '2', '2', '0', '0', '0', '1', '0', '0', '7', '0', '0', '0', '1440140979', '1440140979', '1', '');
INSERT INTO `onethink_document` VALUES ('11', '2', '', '埃索美拉唑钠', '4', '0', '', '0', '0', '6', '2', '0', '0', '20', '1', '0', '0', '3', '0', '0', '0', '1440141960', '1440144703', '1', '埃索美拉唑钠');
INSERT INTO `onethink_document` VALUES ('12', '2', '', '埃索美拉唑镁三水合物', '4', '0', '', '0', '0', '6', '2', '0', '0', '19', '1', '0', '0', '1', '0', '0', '0', '1440142140', '1440144667', '1', '埃索美拉唑镁三水合物,');
INSERT INTO `onethink_document` VALUES ('13', '2', '', 'Boc-2-氨甲基苯乙酸', '4', '0', '', '0', '0', '6', '2', '0', '0', '18', '1', '0', '0', '2', '0', '0', '0', '1440142320', '1440144632', '1', 'Boc-2-氨甲基苯乙酸');
INSERT INTO `onethink_document` VALUES ('14', '2', '', '2-氨基甲基苯乙酸', '4', '0', '', '0', '0', '6', '2', '0', '0', '17', '1', '0', '0', '2', '0', '0', '0', '1440142380', '1440144592', '1', '2-氨基甲基苯乙酸');
INSERT INTO `onethink_document` VALUES ('15', '2', '', '亚硝基硫酸钾', '4', '0', '', '0', '0', '6', '2', '0', '0', '16', '1', '0', '0', '3', '0', '0', '0', '1440142500', '1440144554', '1', '亚硝基硫酸钾');
INSERT INTO `onethink_document` VALUES ('16', '2', '', '左旋樟脑', '4', '0', '', '0', '0', '6', '2', '0', '0', '21', '1', '0', '0', '3', '0', '0', '0', '1440142560', '1440146072', '1', '左旋樟脑');
INSERT INTO `onethink_document` VALUES ('17', '2', '', '右旋樟脑磺酸', '4', '0', '', '0', '0', '6', '2', '0', '0', '15', '1', '0', '0', '2', '0', '0', '0', '1440142620', '1440144477', '1', '右旋樟脑磺酸');
INSERT INTO `onethink_document` VALUES ('18', '2', '', 'R-(-)-5-(2-氨基丙基)-2-甲氧基苯磺酰胺', '4', '0', '', '0', '0', '6', '2', '0', '0', '14', '1', '0', '0', '0', '0', '0', '0', '1440143220', '1440144435', '1', 'R-(-)-5-(2-氨基丙基)-2-甲氧基苯磺酰胺');
INSERT INTO `onethink_document` VALUES ('19', '2', '', '右兰索拉唑', '4', '0', '', '0', '0', '6', '2', '0', '0', '13', '1', '0', '0', '0', '0', '0', '0', '1440143280', '1440144400', '1', '右兰索拉唑');
INSERT INTO `onethink_document` VALUES ('20', '2', '', '联硼酸新戊二醇酯', '4', '0', '', '0', '0', '6', '2', '0', '0', '12', '1', '0', '0', '0', '0', '0', '0', '1440143280', '1440144360', '1', '联硼酸新戊二醇酯');
INSERT INTO `onethink_document` VALUES ('21', '2', '', '联硼酸频那醇酯', '4', '0', '', '0', '0', '6', '2', '0', '0', '11', '1', '0', '0', '0', '0', '0', '0', '1440143340', '1440144314', '1', '联硼酸频那醇酯');
INSERT INTO `onethink_document` VALUES ('22', '2', '', '阿比特龙', '4', '0', '', '0', '0', '6', '2', '0', '0', '10', '1', '0', '0', '0', '0', '0', '0', '1440143400', '1440144269', '1', '阿比特龙');
INSERT INTO `onethink_document` VALUES ('23', '2', '', '醋酸阿比特龙', '4', '0', '', '0', '0', '6', '2', '0', '0', '9', '1', '0', '0', '1', '0', '0', '0', '1440143400', '1440144230', '1', '醋酸阿比特龙');
INSERT INTO `onethink_document` VALUES ('24', '2', '', '1-(2-二甲基氨基乙基)-1H-5-巯基-四氮唑', '4', '0', '', '0', '0', '6', '2', '0', '0', '8', '1', '0', '0', '1', '0', '0', '0', '1440143460', '1440144177', '1', '1-(2-二甲基氨基乙基)-1H-5-巯基-四氮唑');
INSERT INTO `onethink_document` VALUES ('25', '2', '', '盐酸普乐沙福', '4', '0', '', '0', '0', '6', '2', '0', '0', '7', '1', '0', '0', '0', '0', '0', '0', '1440143640', '1440144116', '1', '盐酸普乐沙福');
INSERT INTO `onethink_document` VALUES ('26', '2', '', '1,4,8,11-四氮杂环十四烷', '4', '0', '', '0', '0', '6', '2', '0', '0', '6', '1', '0', '0', '0', '0', '0', '0', '1440143700', '1440144085', '1', '1,4,8,11-四氮杂环十四烷');
INSERT INTO `onethink_document` VALUES ('27', '2', '', '比马前列素', '4', '0', '', '0', '0', '6', '2', '0', '0', '5', '1', '0', '0', '0', '0', '0', '0', '1440143700', '1440144057', '1', '比马前列素');
INSERT INTO `onethink_document` VALUES ('28', '2', '', '拉坦前列素', '4', '0', '', '0', '0', '6', '2', '0', '0', '4', '1', '0', '0', '1', '0', '0', '0', '1440143820', '1440144029', '1', '拉坦前列素');
INSERT INTO `onethink_document` VALUES ('29', '2', '', '(R)-(+)-9-(2-羟丙基)腺嘌呤', '4', '0', '', '0', '0', '6', '2', '0', '0', '3', '1', '0', '0', '1', '0', '0', '0', '1440143820', '1440144002', '1', '(R)-(+)-9-(2-羟丙基)腺嘌呤');
INSERT INTO `onethink_document` VALUES ('30', '2', '', 'About Us', '11', '0', 'Nanjing Kailun Pharmaceutical Company, Ltd. focuses on the development of novel chiral catalyst technology and the industrial research of chiral drugs. It is committed to one-stop service for different Demanders.', '0', '0', '5', '1', '0', '0', '0', '0', '1440754500', '0', '13', '0', '0', '0', '1440754500', '1440985017', '1', 'Nanjing Kailun Pharmaceutical Company, Ltd|chiral technology');
INSERT INTO `onethink_document` VALUES ('31', '2', '', 'Contact', '13', '0', 'Contact', '0', '0', '5', '1', '0', '0', '0', '0', '1440754980', '0', '6', '0', '0', '0', '1440754980', '1440755242', '1', 'Contact');

-- -----------------------------
-- Table structure for `onethink_document_article`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_article`;
CREATE TABLE `onethink_document_article` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '文章内容',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `bookmark` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '收藏数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型文章表';

-- -----------------------------
-- Records of `onethink_document_article`
-- -----------------------------
INSERT INTO `onethink_document_article` VALUES ('2', '0', '研发负责人：克里斯蒂安·山多夫\r\n<p class=\"MsoNormal\">\r\n	<img src=\"/Uploads/Editor/2015-08-19/55d3fb5774c8f.png\" alt=\"克里斯蒂安·山多夫与野依良治教授\" width=\"400\" /> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>手性技术国际领域知名技术专家；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>莫纳什大学化学博士；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>曾任日本理研所资深研究员；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b><span>2001</span></b><b>年诺贝尔化学奖得主野依良治教授研发团队成员之一；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\" style=\"text-indent:21.0pt;\">\r\n	新型手性技术研发中心（南京）<span>----</span>于<span>2014</span>年入驻南京创新药物百家汇研发平台，百家汇依托先声药业强大的新药研发科研基础，组建了多个创新药物研发技术平台：抗体药物平台、生物评价平台、分析测试中心、实验动物中心、引进国内外知名<span>CRO</span>公司组成的<span>CRO</span>联盟，为入驻企业提供全方位的研发支持服务。<span></span> \r\n</p>', '', '0');
INSERT INTO `onethink_document_article` VALUES ('3', '0', '<p class=\"MsoNormal\">\r\n	研发负责人<span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<img src=\"/Uploads/Editor/2015-08-19/55d3fddd46df5.jpg\" alt=\"\" width=\"400\" /> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>同济医院药学部副主任；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>药物研究室暨中药研究室主任；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>中国中西医结合学会中药专业委员会秘书；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>湖北省中医中药学会中药专业委员会副主任委员；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>中华中医药学会武汉分会中药专委会副主任委员；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>中国药学会武汉分会常务理事；</b><span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<span>&nbsp;</span> \r\n</p>\r\n<p class=\"MsoNormal\" style=\"text-indent:21.0pt;\">\r\n	励合<span>-</span>同济医学部联合实验平台<span>--------</span>位于东湖国家自主创新示范区武汉生物技术研究院内，武汉生物技术研究院由湖北省委省政府整合武汉大学、华中科技大学、华中农业大学、中科院武汉分院、武汉凯迪控股等高校、科研院所、企业的优势资源组建而成，主要从事生物技术应用研究开发、专业服务和成果转化，是武汉国家生物产业基地的技术支撑平台。研究院建筑面积<span>8</span>万平米，下设六大研究中心，建有公共服务平台和中试转化平台。拥有<span>1</span>万平米的国际准实验室，引进国际一流的试验装备，并确立了以抗肿瘤药、心血管药、内分泌药和手术用药等为重点的创新方向。<span></span> \r\n</p>', '', '0');
INSERT INTO `onethink_document_article` VALUES ('4', '0', '<p class=\"MsoNormal\">\r\n	<img src=\"/Uploads/Editor/2015-08-19/55d3fe89ce655.png\" alt=\"\" width=\"600\" /> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	励合手性药物产业化基地（武汉）<span>----</span>位于武汉市东西湖区走马岭医药园内，建立了湖北省最大的手性药物研发及产业化基地。拥有国际一流的手性技术实验装备及人才。<span></span> \r\n</p>', '', '0');
INSERT INTO `onethink_document_article` VALUES ('9', '0', '<strong>光明网武汉3月19日电（记者夏静&nbsp;通讯员何骏）</strong>19日，由武汉大学绿色催化研究所、天津化学化工2011协同创新中心、同写意新药英才俱乐部共同主办的“摘取化学制药工业的金钥匙——手性技术与制药化学国际高峰论坛”在武汉大学召开。包括南开大学化学学院院长周其林院士在内的4位中科院院士、4名国家“千人计划”专家以及世界知名制药企业代表等参会。专家们围绕绿色催化化学领域的最新进展，探讨了手性技术和创新工艺在制药工业中的应用，旨在促进学术界与产业深度交融，共寻化学工艺创新之道，打造绿色化学制药之路做出了有益探索。\r\n<p style=\"color:#000000;font-family:微软雅黑;font-size:16px;\">\r\n	<br />\r\n<span style=\"font-size:14px;\">　　“用分子创造价值，用创造分子影响世界。一个分子可以创造的价值不亚于制造一部大飞机，软实力也要真功夫。”中国科学院上海有机化学所所长丁奎岭向记者介绍了分子研究的意义。他认为，手性技术对降低制药成本，提高效率，保证安全，促进环保都有着重要作用。</span>\r\n</p>\r\n<p style=\"color:#000000;font-family:微软雅黑;font-size:16px;\">\r\n	<span style=\"font-size:14px;\">　　“当前，我国的手性技术发展主要存在两方面问题。一是产业基础相对薄弱。制药是高精尖行业，新药研发具有高技术、高门槛、高投入三个特征，我国大部分企业不具备新药的研发能力，产业基础较差。二是科研与产业脱节。我们的源头基础创新已达国际一流水平，但是企业没有用上，科研与产业出现衔接断裂问题。”周其林院士说，“今年《政府工作报告》中提出‘全民创新’的概念，而在手性技术方面就是要打通创新‘全链条’，实现基础应用的源头创新、技术转换的研发创新、产品制造的生产创新三方面之间的有效衔接。”</span>\r\n</p>\r\n<p style=\"color:#000000;font-family:微软雅黑;font-size:16px;\">\r\n	<span style=\"font-size:14px;\">　　据了解，所谓手性，就是指一个物体与其镜像不重合，就像人类的双手，虽然都是“手”，但“左手”和“右手”却可能有着截然不同的作用。而手性分子同样如此，在化学合成过程中，有效的分子和无效甚至有害的分子各占一半，科学家费尽心力，试验着各种技术手段，争取不产生无效乃至有害的分子。手性催化技术就是目前最先进的技术手段。</span>\r\n</p>\r\n<p style=\"color:#000000;font-family:微软雅黑;font-size:16px;\">\r\n	<span style=\"font-size:14px;\">　　此次论坛汇聚了我国手性技术领域的顶尖专家。周其林院士所设计的络合物催化剂可达到450万转化数，是目前全球最高；丁奎岭院士发明的手性催化剂不仅简化了冗长的合成工艺为两部，而且效率提高31倍；冯晓明院士发明的“Roskamp-Feng”，武汉大学绿色催化研究所所长张绪穆教授“Zhang-enynecycloisomerization”均被收录进国际化学界承认的人名反应。</span>\r\n</p>\r\n<p style=\"color:#000000;font-family:微软雅黑;font-size:16px;\">\r\n	<span style=\"font-size:14px;\"><span style=\"background-color:#FAEBD7;\">本文转载自</span><span style=\"line-height:24.99px;\"><span style=\"background-color:#FAEBD7;\">光明网</span></span><span style=\"color:#666666;line-height:24.99px;\"><span style=\"background-color:#FAEBD7;\">，</span></span><span><span style=\"background-color:#FAEBD7;\">责任编辑:李国强</span></span></span>\r\n</p>', '', '0');
INSERT INTO `onethink_document_article` VALUES ('10', '0', '<p>\r\n	<strong><span style=\"color:#FF0000;font-size:18px;\">4个方面的因素影响手性技术产业化：一是催化剂的转化数，一般在实验室转化数到1万以上的催化剂才有产业化价值;二是反应条件不能太苛刻，需要适应工业生产的要求;三是催化剂的成本不能太高;四是企业自身需要一定的研发水平。</span></strong>\r\n</p>\r\n<p>\r\n	<span style=\"color:#3E3E3E;line-height:24px;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">随着整个社会对环保的重视度提升，新《环境保护法》也在今年正式实施，我国的原料药企业面临着越来越大的环保压力。同时，行业竞争加剧，探索环保、高效的合成技术成为制药企业转型的重要策略。</span>\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　手性催化技术是全球化学制药工业最先进的技术之一。在这一领域，中国有一流的科学家和科研实力，但先进的手性催化技术在制药工业中的应用并不广泛，大多数企业仍使用落后的技术和传统的工艺手段，带来沉重的环境污染问题。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　“<span style=\"background-color:#ADD8E6;\">一边是工业界，一边是学术界，距离好像很远。二者必须加强合作，将科研成果转化为生产力，创造出新型的产业和新的经济增长点</span>。”3月20日，在武汉大学举行的“手性技术与制药化学国际高峰论坛暨同写意论坛第35期论坛活动”上，我国著名有机化学家、中国科学院院士戴立信如是说。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	<img style=\"width:622px;height:329px;\" alt=\"\" src=\"http://www.tongxieyi.com/u/cms/www/201503/28235900m6qg.jpg\" />\r\n</p>\r\n<h2 class=\"bfcolor\" style=\"color:#8A2E2E;font-family:微软雅黑;font-size:16px;font-weight:400;\">\r\n	<span style=\"font-family:sans-serif;\">环保利器</span>\r\n</h2>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　自然界有许多分子含有不对称碳，即一个碳上四个基团互不相同，导致分子与其镜像(对映体)不重合，恰如人的左手和右手互成镜像，却不能重合，这一属性被人们形象地称为“手性”。据悉，改变我们生活的300个最重要的分子、全球正在研制的1000多种新药中，大约7成是手性化合物。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　手性分子及其对映体的等摩尔混合物被称为外消旋体。手性分子及其对映体除了光学性质不同外，其他物理性质一般相同，但是其药理活性却不一定相同，甚至存在很大的差异。例如反应停(沙利度胺)就是一种手性药物，其分子结构中含有一个手性中心，形成两种光学异构体，其中构型R-(+)的结构有中枢镇静作用，另一种构型S-(-)的对映体则有强烈的致畸性。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　从化学角度而言，合成单一的手性异构体有两种方法，即手性拆分和手性催化。经典化学反应一般得到等量左旋体和右旋体的混合物，用手性拆分试剂将混旋体拆分成左旋体和右旋体，会得到一半副产物，不仅反应本身原子经济性差，还需要消耗大量手性拆分试剂，从而造成巨大浪费和环境污染。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　手性催化合成技术应运而生，在极少量的手性催化剂作用下获得大量的单旋体。“手性合成可以使部分原料药生产成本降低50%以上。”武汉大学化学与分子科学学院绿色催化研究所所长张绪穆教授表示，世界药物合成制造业已经转移到中国，每生产1公斤医药产品通常会产生25～100公斤废物，药物合成过程中会产生涉及环境污染、药物杂质等一系列问题，而手性药物不仅可以大幅降低原料药生产成本，还节能环保。\r\n</p>\r\n<h2 class=\"bfcolor\" style=\"color:#8A2E2E;font-family:微软雅黑;font-size:16px;font-weight:400;\">\r\n	<span style=\"font-family:sans-serif;\">产业化成败的关键</span>\r\n</h2>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　实际上，在手性催化技术领域，我国有着一流的科学家和科研实力。中国科学院院士、南开大学化学学院院长周其林所设计的手性催化剂达到了450万的转化数，是目前全球最高数;四川大学冯小明院士发明了“Roskamp-Feng“反应;中国科学院院士、上海有机研究所所长丁奎岭发明的手性催化技术将冗长的合成工艺简化为两步，效率提高31倍;张绪穆教授发明的环化反应被国际化学权威著作命名为“Zhang-enyncycloisomeriation”。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　然而，我国的化学科研能力和工业水平并不对称，大部分制药企业并未引入先进的生产技术，加上做中间体、原料药的企业大多微利运营，没有更多的资金投入来做环保、做研发。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　随着产业升级的需求日益强烈，也有少数企业选择引进海外优秀人才，从优化生产工艺上寻求转型之路。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　周其林院士与九洲药业的合作被视为科研与产业界合作的典范，他设计的配体在400多个竞争者中脱颖而出被罗氏用于新药的制备中。据悉，九洲药业正在着力建设新药所需的原料药及高级中间体的CMO多功能生产基地和CRO/CMO研发中心，加强公司为原研制药公司提供“定制研发+定制生产”的服务能力，逐渐从传统的特色原料药和中间体生产业务向下游延伸。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　周其林院士指出，4个方面的因素影响手性技术产业化：第一，催化剂的转化数，一般在实验室转化数到1万以上的催化剂才有产业化价值;第二，反应条件不能太苛刻，需要适应工业生产的要求;第三，催化剂的成本不能太高;第四，企业自身需要研发水平，这是问题的关键所在。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　戴立信院士在大会总结发言中指出，研发是科研与生产之间的纽带，目前国内很多企业自身研发水平不足，难以将实验室的科研成果进行放大应用于产业。\r\n</p>\r\n<p style=\"color:#3E3E3E;font-family:&quot;Helvetica Neue&quot;, Helvetica, &quot;Hiragino Sans GB&quot;, &quot;Microsoft YaHei&quot;, Î¢ÈíÑÅºÚ, Arial, sans-serif;font-size:15px;\">\r\n	　　值得期待的是，随着本土企业越来越重视研发，更多的海归人才加入其中，他们将推动科研与产业的合作。\r\n</p>\r\n<p style=\"text-indent:28px;font-size:15px;\">\r\n	<span style=\"background-color:#ADD8E6;\"><span>本文转载自医药经济报，作者李佳。文章内容根据“手性技术与制药化学国际高峰论坛暨同写意论坛第35期论坛活动”嘉宾现场报告内容整理，未经发言者核实</span><span>，</span><span>如有不确切之处，以发言人发言内容为准。</span></span>\r\n</p>\r\n<p>\r\n	&nbsp;\r\n</p>', '', '0');

-- -----------------------------
-- Table structure for `onethink_document_download`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_download`;
CREATE TABLE `onethink_document_download` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `parse` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '内容解析类型',
  `content` text NOT NULL COMMENT '下载详细描述',
  `template` varchar(100) NOT NULL DEFAULT '' COMMENT '详情页显示模板',
  `file_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件ID',
  `download` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '下载次数',
  `size` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型下载表';


-- -----------------------------
-- Table structure for `onethink_document_product`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_product`;
CREATE TABLE `onethink_document_product` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ä¸»é”®',
  `content` text NOT NULL COMMENT 'è¯¦æƒ…',
  `cas` varchar(25) NOT NULL COMMENT 'cas',
  `spec` varchar(25) NOT NULL COMMENT '规格',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `onethink_document_product`
-- -----------------------------
INSERT INTO `onethink_document_product` VALUES ('11', '<p style=\"color:#333333;font-size:14px;font-family:Arial;\">\r\n	<img src=\"/Uploads/Editor/2015-08-21/55d6dd3dabb95.gif\" alt=\"\" /> \r\n</p>\r\n<p style=\"color:#333333;font-size:14px;font-family:Arial;\">\r\n	中文名称:埃索美拉唑钠<br />\r\nCAS:161796-78-7<br />\r\n英文名称:<span class=\"casenname\">Sodium (S)-6-methoxy-2-(((4-methoxy-3,5-dimethylpyridin-2-yl)methyl)sulfinyl)benzo[d]imidazol-1-ide</span><br />\r\nEINECS:&nbsp;<br />\r\n分子式:C<sub>17</sub>H<sub>18</sub>N<sub>3</sub>O<sub>3</sub>S-<sup>.</sup>Na+<br />\r\n分子量:367.39792\r\n</p>\r\n<p style=\"color:#333333;font-size:14px;font-family:Arial;\">\r\n	<span style=\"color:#3A3A3A;font-family:微软雅黑;font-size:20px;line-height:1.5;\">基本信息</span> \r\n</p>\r\n<p style=\"color:#333333;font-size:14px;margin-left:20px;font-family:Arial;\">\r\n	<b>中文别名:</b>5-甲氧基-2-((S)-((4-甲氧基-3,5-二甲基-2-吡啶基)甲基)亚磺酰基-1H-苯并咪唑钠;埃索美拉唑钠盐;左旋奥美拉唑钠;艾索美拉唑钠<br />\r\n<b>英文别名:</b>5-Methoxy-2-((S)-((4-methoxy-3,5-dimethyl-2-pyridyl)methyl)sulfinyl-1H-benzimidazole sodium salt\r\n</p>\r\n<h2 style=\"font-weight:200;color:#3A3A3A;font-family:微软雅黑;font-size:20px;text-indent:10px;\">\r\n	埃索美拉唑钠性质\r\n</h2>\r\n<p style=\"color:#333333;font-size:14px;margin-left:20px;font-family:Arial;\">\r\n	埃索美拉唑钠是埃索美拉唑的钠盐形式，是一种常用的抗溃疡药，由瑞典Astra Zeneca公司首次研发成功，属质子泵抑制剂，质子泵抑制剂(PPI)是治疗消化性溃疡、胃食管反流病等酸相关疾病的首选药物。目前临床上常用的PPI有奥美拉唑、兰索拉唑、雷贝拉唑、泮托拉唑和埃索美拉唑5种。奥美拉唑作为第一种PPI药物，其治疗酸相关疾病的疗效得到了一致认可。埃索美拉唑是奥美拉唑的S-异构体，通过特异性的耙向作用机制减少胃酸分泌，为壁细胞中质子泵的特异性抑制剂，由于具有代谢优势，埃索美拉唑钠较奥美拉唑具有更高的生物利用度和更一致的药代动力学，使到达质子泵的药物增加，控制胃酸方面的作用明显优于兰索拉唑，泮托拉唑和雷贝拉唑等其他质子泵抑制剂。<br />\r\n在动物实验中，本品对离体兔胃壁细胞上的Na+/K+ATP酶的活性具有剂量依赖性的抑制作用，其IC50为60 μmol/L。药效大于奥美拉唑(IC50为100 μmol/L)。同时，埃索美拉唑钠还能抑制组胺引起的离体人胃壁细胞中14C氨基比林的蓄积，作用强度为奥美拉唑的2倍。<br />\r\n给实验性造瘘大鼠模型静脉或肠内注射埃索美拉唑钠后，能抑制组胺引起的胃酸分泌，其ED50分别为0.24和0.43 mg/kg。而奥美拉唑同途径给药时的ED50则分别为0.30和 0.68 mg/kg。<br />\r\n幽门结扎大鼠肠内使用埃索美拉唑钠，可使其基础胃酸分泌量下降，作用强度比奥美拉唑大3倍。该药还可预防实验大鼠应激性或酒精性胃损伤并对消炎痛和醋酸引起的胃损伤有防治作用，其ED50值分别为1.6和5.5 mg/kg。从上述实验结果可见，埃索美拉唑对溃疡的疗效大于奥美拉唑。<br />\r\n此外，还有试验数据表明，当埃索美拉唑钠与青霉素及克红霉素合用时，可有效治疗幽门螺杆菌感染引起的十二指肠溃疡和消化道溃疡。\r\n</p>\r\n<h2 style=\"font-weight:200;color:#3A3A3A;font-family:微软雅黑;font-size:20px;text-indent:10px;\">\r\n	埃索美拉唑钠用途\r\n</h2>\r\n<p style=\"color:#333333;font-size:14px;margin-left:20px;font-family:Arial;\">\r\n	食管反流性疾病(GERD)-糜烂性反流性食管炎的治疗。<br />\r\n已经治愈的食管炎患者防止复发的长期维持治疗。<br />\r\n胃食管反流性疾病(GERD)的症状控制。<br />\r\n胃灼热和与适当的抗菌疗法联合用药根除幽门螺杆菌引起的胃及十二指肠溃疡。<br />\r\n本品应与水一起吞服，不能咀嚼或粉碎后服用。<br />\r\n成人:治疗侵蚀性反流性食管炎为40mg，每日1次，用药4～8周。食管炎治愈病人长期维持治疗和预防复发的推荐剂量为 20mg，每日1次。治疗未患食管炎的症状性CORD为20mg，每日1次，用药4周(如未能控制症状，则应对病人进行进一步的观察)。一旦症状得到控制，则可按需使用本品控制以后的症状，每日20 mg。根除幽门螺杆菌、治愈幽门螺杆菌引起的十二指肠溃疡和预防幽门螺杆菌引起的消化道溃疡复发的三联疗法为本品20mg，阿莫西林1g和克拉霉素500mg，每日2次，用药7d。<br />\r\n老年病人及轻中度肝功能受损无需调整剂量，严重肝功能受损者使用时应注意，最大剂量不应超过20 mg。<br />\r\n儿童和哺乳期妇女不推荐使用。\r\n</p>', '161796-78-7', '');
INSERT INTO `onethink_document_product` VALUES ('12', '<p style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	<img src=\"/Uploads/Editor/2015-08-21/55d6dd1a0d5c9.gif\" alt=\"\" /> \r\n</p>\r\n<p style=\"color:#333333;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	埃索美拉唑镁(三水)\r\n</p>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	英文名称：Esomeprazole magnesium trihydrate\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	中文别名：二(5-甲氧基-2-[(S)-[(4-甲氧基-3,5-二甲基-2-吡啶基)甲基]亚磺酰基]-1H-苯并咪唑-1-基)镁盐三水合物；埃索美拉唑镁(三水)；三水埃索美拉唑镁；埃索美拉唑镁三水合物[1]；埃索美拉唑三水镁盐\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	英文别名：ESOMEPRAZOLE MAGNESIUM TRIHYDRATE；bis(5-methoxy-2-[(s)-[(4-methoxy-3,5-dimethyl-2-pyridinyl)methyl]sulfinyl]-1h-benzylimidazole-1-yl) magnesium trihydrate；(T-4)-Bis[5-methoxy-2-[(S)-[(4-methoxy-3,5-dimethyl-2-pyridinyl)methyl]sulfinyl]-1H-benzimidazolato]magnesium；ESOMEPRAZOLE MAGNESIUM TRIHYDRATE USP；5-methoxy-2-[(4-methoxy-3,5-dimethyl-pyridin-2-yl)methylsulfinyl]benzimidazol-1-ide；(S)-OMeprazole MagnesiuM trihydrate\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	CAS：217087-09-7\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	分子式：C34H42MgN6O9S2\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	分子量：767.16\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	含量：98.0%～102.0%(HPLC)\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	性状：白色或类白色粉末，略有吸湿性。\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	熔点：184-189℃ (dec.)\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	沸点：600℃ at 760 mmHg\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	闪点：316.7℃\r\n</div>\r\n<div class=\"para\" style=\"color:#333333;margin:15px 0px 5px;font-family:arial, 宋体, sans-serif;font-size:14px;background-color:#FFFFFF;\">\r\n	蒸气压：2.35E-14mmHg at 25℃\r\n</div>', '217087-09-7', '');
INSERT INTO `onethink_document_product` VALUES ('13', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6dcf5cb538.gif\" alt=\"\" /></span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:Boc-2-氨甲基苯乙酸</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">40851-66-9</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">2-(2-(((tert-Butoxycarbonyl)amino)methyl)phenyl)acetic acid</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">&nbsp;</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>14</sub>H<sub>19</sub>NO<sub>4</sub></span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">265.30496</span>', '40851-66-9', '');
INSERT INTO `onethink_document_product` VALUES ('14', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6dccebe25d.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:2-氨基甲基苯乙酸</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">40851-65-8</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">[2-(aminomethyl)phenyl]acetic acid</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">255-110-3</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>9</sub>H<sub>11</sub>NO<sub>2</sub></span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">165.18914</span>', '40851-65-8', '');
INSERT INTO `onethink_document_product` VALUES ('15', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6dca8b6f88.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:&nbsp;亚硝基硫酸钾</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">14293-70-0</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">Nitrosodisulfonic acid,potassium salt (1:2)</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">&nbsp;</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">H<sub>3</sub>NO<sub>7</sub>S<sub>2</sub></span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">193.15632</span>', '14293-70-0', '');
INSERT INTO `onethink_document_product` VALUES ('16', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6e2974c201.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:左旋樟脑</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">464-48-2</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">L(-)-Camphor</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">207-354-7</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>10</sub>H<sub>16</sub>O</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">&nbsp;152.23</span>', '464-48-2', '');
INSERT INTO `onethink_document_product` VALUES ('17', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6dc5b7ff09.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:D(+)-10-樟脑磺酸</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">3144-16-9</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">((1S,4R)-7,7-Dimethyl-2-oxobicyclo[2.2.1]heptan-1-yl)methanesulfonic acid</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">221-554-1</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>10</sub>H<sub>16</sub>O<sub>4</sub>S</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">232.29664</span>', '3144-16-9', '');
INSERT INTO `onethink_document_product` VALUES ('18', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6dc31eb6af.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:R-(-)-5-(2-氨基丙基)-2-甲氧基苯磺酰胺</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">112101-81-2</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">5-[(2R)-2-Aminopropyl]-2-methoxy benzene sulfonamide</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">&nbsp;</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>10</sub>H<sub>16</sub>N<sub>2</sub>O<sub>3</sub>S</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">244.31</span>', '112101-81-2', '');
INSERT INTO `onethink_document_product` VALUES ('19', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6dc0b414ea.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:(R)-兰索拉唑</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">138530-94-6</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">(R)-Lansoprazole</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">&nbsp;</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>16</sub>H<sub>14</sub>F<sub>3</sub>N<sub>3</sub>O<sub>2</sub>S</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">369.36</span>', '138530-94-6', '');
INSERT INTO `onethink_document_product` VALUES ('20', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6dbe644d31.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:联硼酸新戊二醇酯</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">201733-56-4</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">5,5,5\',5\'-Tetramethyl-2,2\'-bi(1,3,2-dioxaborinane)</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">&nbsp;</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>10</sub>H<sub>20</sub>B<sub>2</sub>O<sub>4</sub></span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">225.8854</span>', '201733-56-4', '');
INSERT INTO `onethink_document_product` VALUES ('21', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6dbb7ed9d7.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:联硼酸频那醇酯</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">73183-34-3</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">bis(pinacolato)diboron</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">&nbsp;</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>12</sub>H<sub>24</sub>B<sub>2</sub>O<sub>4</sub></span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">253.94</span>', '73183-34-3', '');
INSERT INTO `onethink_document_product` VALUES ('22', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6db8ba4ac1.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:阿比特龙</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">154229-19-3</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">(3beta)-17-(3-pyridinyl)-androsta-5,16-dien-3-ol</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">&nbsp;</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>24</sub>H<sub>31</sub>NO</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">349.50904</span>', '154229-19-3', '');
INSERT INTO `onethink_document_product` VALUES ('23', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"/Uploads/Editor/2015-08-21/55d6db620ce26.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:&nbsp;醋酸阿比特龙</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">34375-39-8</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">Hexanedioic acid,1,6-bis(2-acetylhydrazide)</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">&nbsp;</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>10</sub>H<sub>18</sub>N<sub>4</sub>O<sub>4</sub></span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">258.27432</span>', '34375-39-8', '');
INSERT INTO `onethink_document_product` VALUES ('24', '<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\"><img src=\"http://www.chemicalbook.com/CAS/GIF/61607-68-9.gif\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">中文名称:5-巯基-1-二甲氨基乙基</span> \r\n</p>\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">CAS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">61607-68-9</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">英文名称:</span><span class=\"casenname\" style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">1-(2-Dimethylaminoethyl)-5-Mercapto-1,2,3,4-Tetrazole</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">EINECS:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">262-868-9</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子式:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">C<sub>5</sub>H<sub>11</sub>N<sub>5</sub>S</span><br />\r\n<span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">分子量:</span><span style=\"color:#333333;font-family:Arial;font-size:14px;line-height:30px;\">173.24</span>', '61607-68-9', '');
INSERT INTO `onethink_document_product` VALUES ('25', '<p>\r\n	<span><img src=\"http://www.chemicalbook.com/CAS/GIF/110078-46-1.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span>普乐沙福八盐酸盐 155148-31-5</span> \r\n</p>\r\n<span>中文名称:1,1\'-[1,4-亚苯基双(亚甲基)]双[1,4,8,11-四氮杂环十四烷]</span><br />\r\n<span>中文别名:1,1\'-[1,4-亚苯基双(亚甲基)]双[1,4,8,11-四氮杂环十四烷];AMD 3100辛基盐酸盐;普乐沙福HCL;普乐沙福盐酸盐;盐酸普乐沙福;普乐沙福八盐酸盐</span><br />\r\n<span>英文名称:1,1\'-[1,4-Phenylenebis(methylene)]bis[1,4,8,11-tetraazacyclotetradecane]</span><br />\r\n<span>英文别名:1,1\'-[1,4-PHENYLENEBIS(METHYLENE)]BIS-1,4,8,11-TETRAAZACYCLOTETRADECANE OCTAHYDROCHLORIDE;AMD3100;AMD3100 OCTAHYDROCHLORIDE;BISCYCLAM;JM3100;SID791;AMD3100 OCTAHYDROCHLORIDE HYDRATE ANHYDROUS;amd3100 octahydrochloride hydrate</span><br />\r\n<span>CAS号: 155148-31-5</span><br />\r\n<span>分子式: C28H54N8</span><br />\r\n<span>分子量: 502.78</span><br />\r\n<span>含量：98%</span><br />\r\n<span>外观：白色至类白色粉末</span><br />\r\n<p>\r\n	用途：普乐沙福治疗骨髓瘤药物\r\n</p>', '155148-31-5', '');
INSERT INTO `onethink_document_product` VALUES ('26', '<p>\r\n	<span><img src=\"http://www.chemicalbook.com/CAS/GIF/295-37-4.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span>中文名称:1,4,8,11-四氮杂环十四烷</span> \r\n</p>\r\n<span>中文别名:1,4,8,11-四叠氮环十四烷;普乐沙福中间体;FREMY\'S盐</span><br />\r\n<span>英文名称:1,4,8,11-TETRAAZACYCLOTETRADECANE</span><br />\r\n<span>英文别名:jm1498;1,4,8,11-TETRAAZACYCLOTETRADECANE;CYCLAM;Cyclam, 98+%;Cyclam=1,4,8,11-Tetraazacyclotetradecane;1,4,8,11-Tetraazacyclotetradecane, 99+%;1,4,8,11-Tetraazacyclotetradecane,min.98%CYCLAM;1,4,8,11-TETRAAZACYCLOTETRADECANE(CYCLAM)</span><br />\r\n<span>CAS号: 295-37-4</span><br />\r\n<span>分子式: C10H24N4</span><br />\r\n<span>分子量: 200.32</span><br />\r\n<span>外观性状：白色轻质针状晶体&nbsp;</span><br />\r\n<span>熔点：184-186 °C(lit.)&nbsp;</span><br />\r\n<span>最大单项杂质： ≤0.5%&nbsp;</span><br />\r\n<span>总杂：≤0.5%&nbsp;</span><br />\r\n<span>干燥失重： ≤0.5%&nbsp;</span><br />\r\n<span>纯 度：99%以上&nbsp;</span><br />\r\n<span>用途：普乐沙福中间体</span><br />\r\n<span>包装：1kg，5kg铝箔袋</span>', '295-37-4', '');
INSERT INTO `onethink_document_product` VALUES ('27', '<p>\r\n	<span><img src=\"http://www.chemicalbook.com/CAS/GIF/155206-00-1.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span>中文名称：比马前列素</span> \r\n</p>\r\n<span>中文别名 :(Z)-7-[(1R,2R,3R,5S)-3,5-二羟基-2-[(E,3S)-3-羟基-5-苯基戊-1-烯基]环戊基]-N-乙基庚-5-烯酰胺;比马前列腺素;贝美前列素;比马前列腺</span><br />\r\n<span>英文名称：Bimatoprost</span><br />\r\n<span>英文别名：(Z)-7-[(1R,2R,3R,5S)-3,5-Dihydroxy-2-[(E,3S)-3-hydroxy-5-phenylpent-1-enyl]cyclopentyl]-N- ethylhept-5-enamide</span><br />\r\n<span>分子式：C25H37NO4</span><br />\r\n<span>分子量：415.57794</span><br />\r\n<span>CAS：155206-00-1</span><br />\r\n<span>化学性质</span><br />\r\n<span>密度：1.145g/cm3</span><br />\r\n<span>沸点：629.8°C at 760 mmHg</span><br />\r\n<span>闪点： 334.7°C</span><br />\r\n<span>含量：99.5%</span><br />\r\n<span>性 状：白色粉末</span><br />\r\n<span>纯度：99.5%</span><br />\r\n<span>用途：目前降IOP最强的抗青光眼药物</span><br />\r\n<span>包装：1g/铝箔袋</span><br />\r\n<span>对应中间体：2-氧代-4-苯丁基磷酸二甲酯 4-羧丁基三苯基溴化膦</span><br />\r\n<p>\r\n	存储条件：低温避光保存\r\n</p>', '155206-00-1', '');
INSERT INTO `onethink_document_product` VALUES ('28', '<p>\r\n	<span><img src=\"http://www.chemicalbook.com/CAS/GIF/130209-82-4.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span>中文名称：拉坦前列素</span> \r\n</p>\r\n<span>英文名称：Latanoprost&nbsp;</span><br />\r\n<span>中文别名：拉坦前列素；7-[3,5-二羟基-2-(3-羟基-5-苯基戊基)-环戊烷]庚-5-烯酸异丙酯；拉坦前列腺素；[1R-[1Α(Z),2Β(R^&lt;*&gt;^),3Α,5Α]]-7-[3,5-二羟基-2-(3-羟基-5-苯基戊基)环戊基]-5-庚烯酸1-甲基乙基酯&nbsp;</span><br />\r\n<span>英文别名：ISOPROPYL (5Z, 9A,11A,15R)-9,11,15-TRIHYDROXY-17-PHENYL-18,19,20-TRINOR-PROST-5Z-EN-1-OATE；LATANOPROST；17-PHENYL-13,14-DIHYDRO TRINOR PROSTAGLANDIN F2ALPHA ISOPROPYL ESTER；9ALPHA,11ALPHA,15R-TRIHYDROXY-17-PHENYL-18,19,20-TRINOR-PROST-5Z-EN-1-OIC ACID, ISOPROPYL ESTER；(1r-(1-alpha(z),2-beta(r*),3-alpha,5-alpha))--methylethyleste；7-(3,5-dihydroxy-2-(3-hydroxy-5-phenylpentyl)cyclopentyl)-5-heptenoicaci1；isopropyl (5z,9α,11α,15r)-9,11,15-trihydroxy-17-phenyl-18,19,20-trinor-prost-5-en-1-oate；5-Heptenoic acid,7-[(1R,2R,3R,5S)-3,5-dihydroxy-2-[(3R)-3-hydroxy-5-phenylpentyl]cyclopentyl]-,1-methylethyl ester,(5Z)-(9CI)；[1R-[1α(Z)，2β(R^&lt;*&gt;^)，3α，5α]]-7-[3，5-Dihydroxy-2-(3-hydroxy-5-phenyl-pentyl)cyclopentyl]-5-heptenoic acid 1-methylethyl ester；propan-2-yl (5Z)-7-[(1R,2R,3R,5S)-3,5-dihydroxy-2-[(3R)-3-hydroxy-5-phenylpentyl]cyclopentyl]hept-5-enoate；Isopropyl 7-((1R,2R,3R,5S)-3,5-dihydroxy-2-((R)-3-hydroxy-5-phenylpentyl)cyclopentyl)hept-5-enoat&nbsp;</span><br />\r\n<span>CAS：130209-82-4&nbsp;</span><br />\r\n<span>分子式：C26H40O5&nbsp;</span><br />\r\n<span>分子量：432.59&nbsp;</span><br />\r\n<span>含量：99.5%&nbsp;</span><br />\r\n<span>性状：无色至淡黄色油状物；[α]D20+31.57°(C=0.91,乙腈)。&nbsp;</span><br />\r\n<span>密度：1.093g/cm3&nbsp;</span><br />\r\n<span>沸点：583.8℃ at 760 mmHg&nbsp;</span><br />\r\n<span>闪点：188.3℃&nbsp;</span><br />\r\n<span>折射率：1.537&nbsp;</span><br />\r\n<span>水溶性：极易溶于乙腈，易溶于丙酮、乙醇、乙酸乙酯、异丙醇、甲醇或辛醇，几乎不溶于水。&nbsp;</span><br />\r\n<span>用途：用于治疗青光眼和高眼压症,以及各种眼内压增高的病症。&nbsp;</span><br />\r\n<span>储存：−20℃</span>', '130209-82-4 ', '');
INSERT INTO `onethink_document_product` VALUES ('29', '<p>\r\n	<span><img src=\"http://www.chemicalbook.com/CAS/GIF/14047-28-0.gif\" alt=\"\" /><br />\r\n</span> \r\n</p>\r\n<p>\r\n	<span>中文名称:(R)-(+)-9-(2-羟丙基)腺嘌呤</span> \r\n</p>\r\n<span>中文同义词:(R)-(+)-9-(2-羟丙基)腺嘌呤;(R)-9-(2-羟基丙基)腺嘌呤;泰诺福韦第一步的中间体;富马酸泰诺福韦酯中间体;(R)-(+)-9-(2-羟丙基)腺嘌呤(替诺福韦中间体);(R)-9-[2-(羟基丙基)]腺嘌呤(去磷酰替诺福韦);(R)-1-(6-氨基-9H-嘌呤-9-基)丙-2-醇</span><br />\r\n<span>英文名称:(R)-(+)-9-(2-Hydroxypropyl)adenine</span><br />\r\n<span>英文同义词:R-9-(2-hydroxypropyl) adenine, 9-HPA;(R)-(+)-9-(2-HYDROXYPROPYL)ADENINE,98%;(R)-(+)-9-(2-Hydroxypropyl)adenine;6-Amino-alpha-methyl-9H-purine-9-ethanol;D-(-)-9-(2-Hydroxypropyl)adenine;(R)-9-[2-(Hydroxypropyl] Adenine (Desphosphoryl Tenofovir);(R)-6-aMino-alpha-Methyl-9H-purine-9-ethanol;(R)-9-(2-Hydroxypropyl)ademine</span><br />\r\n<span>CAS号: 14047-28-0</span><br />\r\n<span>分子式: C8H11N5O</span><br />\r\n<span>分子量: 193.21</span><br />\r\n<span>外观：白色或类白色结晶性粉末</span><br />\r\n<span>熔点：190-193℃</span><br />\r\n<span>含量：98%</span><br />\r\n<span>干燥失重：2.0%</span><br />\r\n<span>用途：泰诺福韦中间体</span>', '14047-28-0', '');

-- -----------------------------
-- Table structure for `onethink_document_single`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_document_single`;
CREATE TABLE `onethink_document_single` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文档ID',
  `content` text NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文档模型单页表';

-- -----------------------------
-- Records of `onethink_document_single`
-- -----------------------------
INSERT INTO `onethink_document_single` VALUES ('5', '<p style=\"text-indent:2em;\">\r\n	南京楷伦生物医药科技有限公司专注于新型手性催化技术开发及手性药物产业化研究，致力于为国内外制药企业、新药研发机构、科研院所、高校等提供国际领先、优质、经济的新型手性技术开发与手性药物制备一站式服务。\r\n</p>\r\n<p style=\"text-indent:2em;\">\r\n	团队负责人克里斯蒂安 ∙ 山多夫(Christion Ambrosio Sandoval)教授，师从世界著名化学家野依良治教授（2001年其在手性技术领域的特殊贡献被授予诺贝尔化学奖），先后担任日本名古屋化学工业研究所，中科院上海有机所资深专家，入选2015 南京“ 321 人才”引进计划。有着极其丰富手性技术开发及产业化的经验，产品与技术均处于世界前沿。\r\n</p>\r\n<p style=\"text-indent:2em;\">\r\n	南京楷伦生物医药科技有限公司借助控股公司武汉励合化学新材料有限公司在手性技术领域强大的技术背景及市场渠道，力争用五到八年时间在南京建立世界先进的手性药物产业化基地，为海内外药企提供最好的手性药物产业化方案。\r\n</p>');
INSERT INTO `onethink_document_single` VALUES ('8', '<p style=\"text-align:center;\">\r\n	<img src=\"/Uploads/Editor/2015-08-21/55d691bfd0add.jpg\" alt=\"销售网络\" /> \r\n</p>');
INSERT INTO `onethink_document_single` VALUES ('31', '<ul>\r\n	<li>\r\n		NANJING KAILUN BIO-TECHNOLOGY CO.,LTD\r\n	</li>\r\n	<li>\r\n		Add: RM303, NO.32 BLDG, BSK Community , NO.699-18 Xuanwu &nbsp;Street, Xuanwu district, Nanjing city, Jiangsu province, China\r\n	</li>\r\n	<li>\r\n		Tel: 0086 25 87787262\r\n	</li>\r\n	<li>\r\n		Fax: 0086 25 87787269\r\n	</li>\r\n	<li>\r\n		Mobile: 0086 13605195901\r\n	</li>\r\n</ul>');
INSERT INTO `onethink_document_single` VALUES ('6', '<p class=\"MsoNormal\" style=\"text-indent:186.75pt;\">\r\n	<b>研发部（<span>3</span>人）<span></span></b> \r\n</p>\r\n<p class=\"MsoNormal\" align=\"left\" style=\"background:white;\">\r\n	<b>岗位职责：</b><br />\r\n1、小分子化合物和中间体的合成；<span><br />\r\n2</span>、完成领导交办的其它各项实验室工作。\r\n</p>\r\n<p class=\"MsoNormal\" align=\"left\" style=\"background:white;\">\r\n	<b>岗位要求 （ 全职或兼职）：</b><br />\r\n1、有机化学、药学等相关专业；<span><br />\r\n2</span>、<span>1</span>名博士学历， 良好的英语阅读能力及口语，负责与外籍专家的沟通和负责实验室的管理。<span></span> \r\n</p>\r\n<p class=\"MsoNormal\" align=\"left\" style=\"text-indent:21pt;background:white;\">\r\n	2名 硕士以上学历，或者本科须有两年以上合成经验 ；<span><br />\r\n3</span>、有一定波谱分析能力，能通过核磁、质谱等对化合物结构进行解析；<span> <br />\r\n4</span>、能进行相关的英文文献检索并完成相关实验；<span><br />\r\n5</span>、热爱实验室工作，喜欢挑战，具有团队合作精神，责任心强，吃苦耐劳，积极主动。<span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	&nbsp;\r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>待遇</b>：面议。<span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	工作地点：南京徐庄软件园<span></span> \r\n</p>\r\n<p class=\"MsoNormal\" style=\"text-indent:150.6pt;\">\r\n	<b>&nbsp;</b> \r\n</p>\r\n<p class=\"MsoNormal\" style=\"text-indent:150.6pt;\">\r\n	<b>&nbsp;</b> \r\n</p>\r\n<p class=\"MsoNormal\" style=\"text-indent:150.6pt;\">\r\n	<b>政府项目经理<span>(1</span>人<span>)</span></b> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>岗位职责（全职 或 兼职）：</b><br />\r\n1．负责公司知识产权（专利、商标、软件著作权）的申报和管理工作；收集、了解与企业相关的各类国家和地方优惠、扶持、奖励政策信息，查找各类企业及产品荣誉、资质相关项目申报条件、流程；<span> <br />\r\n2</span>．积极参加政府类的相关培训和会议，收集整理政策、行业信息，安排布置适合公司的申报项目；<span><br />\r\n3</span>．负责公司政府项目申报和管理工作（包括：创新基金的申报、高新技术成果转化项目认定、企业融资等）；对项目立项分析、申报对策，项目包装及相关事务的办理；<span><br />\r\n4</span>．协调企业内部相关部门准备和收集文档资料，编制项目申报材料，完成申报任务，跟踪项目进展和主管部门评审进度；进行项目验收资料的准备、送审和验收，申报项目的后期验证等给予协助；<span><br />\r\n5</span>．收集企业发展情况和政策利弊信息，加强对政府主管部门的汇报和建议；负责企业领军人物和研发技术人员的个人荣誉和资质申报；负责各项主管部门要求的统计数据工作的协调收集和汇总申报；<span><br />\r\n<br />\r\n</span><b>岗位要求</b><b>（ 全职或兼职）：</b><span><br />\r\n1</span>．研究生以上学历，化学，工商管理、新闻或其他相关专业毕业；<span> <br />\r\n2.</span>三年以上政府事务工作经验，具备较强的政府政策研究和解读的能力（国家宏观政策；科技部、工信部、发改委、各级部门的科技发展和产业扶持政策）；<span><br />\r\n3</span>．具备项目策划的能力，或对拟申报的项目申报材料审核并提出合理性建议；依据项目申报政策、标准与流程，能够独立组织完成项目申报；<span><br />\r\n4</span>．具备政府资助项目相关经验，熟悉项目申报直至验收流程，有创新基金申报、科技项目申报、软件著作权申报、软件产品申报、高新企业申报等申报经验，熟悉国家相关政策法律法规；具备较强的公关能力，能够提升项目申报的成功率；<span><br />\r\n5</span>．具有较深厚的文字功底，善于报告撰写；具备政府事务专业知识，熟悉政府事务流程，熟悉商业和政务礼仪者优先。<span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	&nbsp;\r\n</p>\r\n<p class=\"MsoNormal\">\r\n	<b>待遇</b>：面议。<span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	工作地点：南京徐庄软件园先声药业\r\n百家汇<span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	工作时间：全职，兼职均可。<span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	&nbsp;\r\n</p>\r\n<p class=\"MsoNormal\">\r\n	如有意加盟，\r\n请联系：<span></span> \r\n</p>\r\n<p class=\"MsoNormal\">\r\n	傅雪青\r\n</p>\r\n<p class=\"MsoNormal\" align=\"left\">\r\n	南京楷伦生物医药科技有限公司\r\n</p>\r\n<p class=\"MsoNormal\" align=\"left\">\r\n	南京市庐山路158号嘉业国际城2号楼610， 210019\r\n</p>\r\n<p class=\"MsoNormal\" align=\"left\">\r\n	T: 025-87787262\r\n</p>\r\n<p class=\"MsoNormal\" align=\"left\">\r\n	F: 025-87787263\r\n</p>\r\n<p class=\"MsoNormal\" align=\"left\">\r\n	M: 13605195901\r\n</p>\r\n<p class=\"MsoNormal\" align=\"left\">\r\n	E MAIL:&nbsp; <span><a href=\"mailto:Sherryfu@vip.sina.com\">Sherryfu@vip.sina.com</a></span>&nbsp;\r\n</p>');
INSERT INTO `onethink_document_single` VALUES ('7', '<ul>\r\n	<li>\r\n		单位：南京楷伦生物医药科技有限公司\r\n	</li>\r\n	<li>\r\n		地址：江苏省南京市玄武区玄武大道699-18号百家汇创业社区32栋303室\r\n	</li>\r\n	<li>\r\n		T:  0086 25 87787262\r\n	</li>\r\n	<li>\r\n		F:  0086 25 87787269\r\n	</li>\r\n	<li>\r\n		M: 0086 13605195901\r\n	</li>\r\n	<li>\r\n		E-MAIL:  \r\n                sherryfu#canopharm.com &nbsp;&nbsp;\r\n                emmazhang#canopharm.com &nbsp;&nbsp;\r\n                alexzhang#canopharm.com &nbsp;(将#号替换为@)\r\n	</li>\r\n</ul>');
INSERT INTO `onethink_document_single` VALUES ('30', 'Nanjing Kailun Pharmaceutical Company, Ltd. focuses on the development of novel chiral catalyst technology and the industrial research of chiral drugs. It is committed to one-stop service for overseas and domestic pharmaceutical companies, new drug D&amp;R centers, research institutes, colleges and universities, which involves providing the advanced, high quality, and economical new chiral technology and preparation of chiral drugs.&nbsp;<br />\r\n<br />\r\nThe team leader, Professor Christion Ambrosio Sandoval studied under  the renowned chemist Ryoji Noyori who was 2001 chemistry Nobel Prize winner in the field of chiral technology. He is experienced in chiral technology development and industrial production. Christion Ambrosio Sandoval served as the Professor at Nagoya University and an expert in Shanghai Institute of organic chemistry, CAS. In 2005, Sandoval was elected to “Nanjing 321” program.<br />\r\n<br />\r\nHeld by Wuhan Li He Chemical and Advanced Materials Company Ltd., Nanjing Kailun Pharmaceutical Company Ltd. is provided with the advanced chiral technology and market channels, which inspires the company to strive to establish the most advanced chiral drugs Industrialization base in Nanjing during to provide the overseas and domestic pharmaceutical companies with the best chiral drug program of industrialization in the recently 5 to 8 years.&nbsp;<br />');

-- -----------------------------
-- Table structure for `onethink_file`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_file`;
CREATE TABLE `onethink_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '远程地址',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上传时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `onethink_focus`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_focus`;
CREATE TABLE `onethink_focus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL DEFAULT '',
  `url` varchar(200) NOT NULL DEFAULT '',
  `pic` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(10) unsigned NOT NULL DEFAULT '0',
  `groups` varchar(20) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_focus`
-- -----------------------------
INSERT INTO `onethink_focus` VALUES ('1', 'banner1', '#', '26', '1', 'focus');
INSERT INTO `onethink_focus` VALUES ('2', 'banner2', '#', '27', '2', 'focus');

-- -----------------------------
-- Table structure for `onethink_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_hooks`;
CREATE TABLE `onethink_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_hooks`
-- -----------------------------
INSERT INTO `onethink_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '', '1');
INSERT INTO `onethink_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'ReturnTop', '1');
INSERT INTO `onethink_hooks` VALUES ('3', 'documentEditForm', '添加编辑表单的 扩展内容钩子', '1', '0', 'Attachment', '1');
INSERT INTO `onethink_hooks` VALUES ('4', 'documentDetailAfter', '文档末尾显示', '1', '0', 'Attachment,SocialComment', '1');
INSERT INTO `onethink_hooks` VALUES ('5', 'documentDetailBefore', '页面内容前显示用钩子', '1', '0', '', '1');
INSERT INTO `onethink_hooks` VALUES ('6', 'documentSaveComplete', '保存文档数据后的扩展钩子', '2', '0', 'Attachment', '1');
INSERT INTO `onethink_hooks` VALUES ('7', 'documentEditFormContent', '添加编辑表单的内容显示钩子', '1', '0', 'Editor', '1');
INSERT INTO `onethink_hooks` VALUES ('8', 'adminArticleEdit', '后台内容编辑页编辑器', '1', '1378982734', 'EditorForAdmin', '1');
INSERT INTO `onethink_hooks` VALUES ('13', 'AdminIndex', '首页小格子个性化显示', '1', '1382596073', 'SiteStat,SystemInfo,DevTeam', '1');
INSERT INTO `onethink_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', 'Editor', '1');
INSERT INTO `onethink_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '', '1');
INSERT INTO `onethink_hooks` VALUES ('17', 'DisplayFocus', '焦点图前台显示钩子', '1', '1439966569', 'Focus', '1');

-- -----------------------------
-- Table structure for `onethink_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_member`;
CREATE TABLE `onethink_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `onethink_member`
-- -----------------------------
INSERT INTO `onethink_member` VALUES ('1', 'admin', '0', '0000-00-00', '', '40', '14', '0', '1439954995', '454105574', '1440985221', '1');
INSERT INTO `onethink_member` VALUES ('2', 'canopharm', '0', '0000-00-00', '', '20', '6', '0', '0', '454105574', '1440984977', '1');

-- -----------------------------
-- Table structure for `onethink_menu`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_menu`;
CREATE TABLE `onethink_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文档ID',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '标题',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '上级分类ID',
  `sort` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '排序（同级有效）',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `hide` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `tip` varchar(255) NOT NULL DEFAULT '' COMMENT '提示',
  `group` varchar(50) DEFAULT '' COMMENT '分组',
  `is_dev` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否仅开发者模式可见',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_menu`
-- -----------------------------
INSERT INTO `onethink_menu` VALUES ('1', '首页', '0', '1', 'Index/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('2', '内容', '0', '2', 'Article/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('3', '文档列表', '2', '0', 'article/index', '1', '', '内容', '0', '1');
INSERT INTO `onethink_menu` VALUES ('4', '新增', '3', '0', 'article/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('5', '编辑', '3', '0', 'article/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('6', '改变状态', '3', '0', 'article/setStatus', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('7', '保存', '3', '0', 'article/update', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('8', '保存草稿', '3', '0', 'article/autoSave', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('9', '移动', '3', '0', 'article/move', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('10', '复制', '3', '0', 'article/copy', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('11', '粘贴', '3', '0', 'article/paste', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('12', '导入', '3', '0', 'article/batchOperate', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('13', '回收站', '2', '0', 'article/recycle', '1', '', '内容', '0', '1');
INSERT INTO `onethink_menu` VALUES ('14', '还原', '13', '0', 'article/permit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('15', '清空', '13', '0', 'article/clear', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('16', '用户', '0', '3', 'User/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('17', '用户信息', '16', '0', 'User/index', '0', '', '用户管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('18', '新增用户', '17', '0', 'User/add', '0', '添加新用户', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('19', '用户行为', '16', '0', 'User/action', '0', '', '行为管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('20', '新增用户行为', '19', '0', 'User/addaction', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('21', '编辑用户行为', '19', '0', 'User/editaction', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('22', '保存用户行为', '19', '0', 'User/saveAction', '0', '\"用户->用户行为\"保存编辑和新增的用户行为', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('23', '变更行为状态', '19', '0', 'User/setStatus', '0', '\"用户->用户行为\"中的启用,禁用和删除权限', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('24', '禁用会员', '19', '0', 'User/changeStatus?method=forbidUser', '0', '\"用户->用户信息\"中的禁用', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('25', '启用会员', '19', '0', 'User/changeStatus?method=resumeUser', '0', '\"用户->用户信息\"中的启用', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('26', '删除会员', '19', '0', 'User/changeStatus?method=deleteUser', '0', '\"用户->用户信息\"中的删除', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('27', '权限管理', '16', '0', 'AuthManager/index', '0', '', '用户管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('28', '删除', '27', '0', 'AuthManager/changeStatus?method=deleteGroup', '0', '删除用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('29', '禁用', '27', '0', 'AuthManager/changeStatus?method=forbidGroup', '0', '禁用用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('30', '恢复', '27', '0', 'AuthManager/changeStatus?method=resumeGroup', '0', '恢复已禁用的用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('31', '新增', '27', '0', 'AuthManager/createGroup', '0', '创建新的用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('32', '编辑', '27', '0', 'AuthManager/editGroup', '0', '编辑用户组名称和描述', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('33', '保存用户组', '27', '0', 'AuthManager/writeGroup', '0', '新增和编辑用户组的\"保存\"按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('34', '授权', '27', '0', 'AuthManager/group', '0', '\"后台 \\ 用户 \\ 用户信息\"列表页的\"授权\"操作按钮,用于设置用户所属用户组', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('35', '访问授权', '27', '0', 'AuthManager/access', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"访问授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('36', '成员授权', '27', '0', 'AuthManager/user', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"成员授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('37', '解除授权', '27', '0', 'AuthManager/removeFromGroup', '0', '\"成员授权\"列表页内的解除授权操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('38', '保存成员授权', '27', '0', 'AuthManager/addToGroup', '0', '\"用户信息\"列表页\"授权\"时的\"保存\"按钮和\"成员授权\"里右上角的\"添加\"按钮)', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('39', '分类授权', '27', '0', 'AuthManager/category', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"分类授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('40', '保存分类授权', '27', '0', 'AuthManager/addToCategory', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('41', '模型授权', '27', '0', 'AuthManager/modelauth', '0', '\"后台 \\ 用户 \\ 权限管理\"列表页的\"模型授权\"操作按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('42', '保存模型授权', '27', '0', 'AuthManager/addToModel', '0', '\"分类授权\"页面的\"保存\"按钮', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('43', '扩展', '0', '7', 'Addons/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('44', '插件管理', '43', '1', 'Addons/index', '0', '', '扩展', '0', '1');
INSERT INTO `onethink_menu` VALUES ('45', '创建', '44', '0', 'Addons/create', '0', '服务器上创建插件结构向导', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('46', '检测创建', '44', '0', 'Addons/checkForm', '0', '检测插件是否可以创建', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('47', '预览', '44', '0', 'Addons/preview', '0', '预览插件定义类文件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('48', '快速生成插件', '44', '0', 'Addons/build', '0', '开始生成插件结构', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('49', '设置', '44', '0', 'Addons/config', '0', '设置插件配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('50', '禁用', '44', '0', 'Addons/disable', '0', '禁用插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('51', '启用', '44', '0', 'Addons/enable', '0', '启用插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('52', '安装', '44', '0', 'Addons/install', '0', '安装插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('53', '卸载', '44', '0', 'Addons/uninstall', '0', '卸载插件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('54', '更新配置', '44', '0', 'Addons/saveconfig', '0', '更新插件配置处理', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('55', '插件后台列表', '44', '0', 'Addons/adminList', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('56', 'URL方式访问插件', '44', '0', 'Addons/execute', '0', '控制是否有权限通过url访问插件控制器方法', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('57', '钩子管理', '43', '2', 'Addons/hooks', '0', '', '扩展', '0', '1');
INSERT INTO `onethink_menu` VALUES ('58', '模型管理', '68', '3', 'Model/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('59', '新增', '58', '0', 'model/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('60', '编辑', '58', '0', 'model/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('61', '改变状态', '58', '0', 'model/setStatus', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('62', '保存数据', '58', '0', 'model/update', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('63', '属性管理', '68', '0', 'Attribute/index', '1', '网站属性配置。', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('64', '新增', '63', '0', 'Attribute/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('65', '编辑', '63', '0', 'Attribute/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('66', '改变状态', '63', '0', 'Attribute/setStatus', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('67', '保存数据', '63', '0', 'Attribute/update', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('68', '系统', '0', '4', 'Config/group', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('69', '网站设置', '68', '1', 'Config/group', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('70', '配置管理', '68', '4', 'Config/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('71', '编辑', '70', '0', 'Config/edit', '0', '新增编辑和保存配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('72', '删除', '70', '0', 'Config/del', '0', '删除配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('73', '新增', '70', '0', 'Config/add', '0', '新增配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('74', '保存', '70', '0', 'Config/save', '0', '保存配置', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('75', '菜单管理', '68', '5', 'Menu/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('76', '导航管理', '68', '6', 'Channel/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('77', '新增', '76', '0', 'Channel/add', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('78', '编辑', '76', '0', 'Channel/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('79', '删除', '76', '0', 'Channel/del', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('80', '分类管理', '68', '2', 'Category/index', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('81', '编辑', '80', '0', 'Category/edit', '0', '编辑和保存栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('82', '新增', '80', '0', 'Category/add', '0', '新增栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('83', '删除', '80', '0', 'Category/remove', '0', '删除栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('84', '移动', '80', '0', 'Category/operate/type/move', '0', '移动栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('85', '合并', '80', '0', 'Category/operate/type/merge', '0', '合并栏目分类', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('86', '备份数据库', '68', '0', 'Database/index?type=export', '0', '', '数据备份', '0', '1');
INSERT INTO `onethink_menu` VALUES ('87', '备份', '86', '0', 'Database/export', '0', '备份数据库', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('88', '优化表', '86', '0', 'Database/optimize', '0', '优化数据表', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('89', '修复表', '86', '0', 'Database/repair', '0', '修复数据表', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('90', '还原数据库', '68', '0', 'Database/index?type=import', '0', '', '数据备份', '0', '1');
INSERT INTO `onethink_menu` VALUES ('91', '恢复', '90', '0', 'Database/import', '0', '数据库恢复', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('92', '删除', '90', '0', 'Database/del', '0', '删除备份文件', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('93', '其他', '0', '5', 'other', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('96', '新增', '75', '0', 'Menu/add', '0', '', '系统设置', '0', '1');
INSERT INTO `onethink_menu` VALUES ('98', '编辑', '75', '0', 'Menu/edit', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('106', '行为日志', '16', '0', 'Action/actionlog', '0', '', '行为管理', '0', '1');
INSERT INTO `onethink_menu` VALUES ('108', '修改密码', '16', '0', 'User/updatePassword', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('109', '修改昵称', '16', '0', 'User/updateNickname', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('110', '查看行为日志', '106', '0', 'action/edit', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('112', '新增数据', '58', '0', 'think/add', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('113', '编辑数据', '58', '0', 'think/edit', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('114', '导入', '75', '0', 'Menu/import', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('115', '生成', '58', '0', 'Model/generate', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('116', '新增钩子', '57', '0', 'Addons/addHook', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('117', '编辑钩子', '57', '0', 'Addons/edithook', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('118', '文档排序', '3', '0', 'Article/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('119', '排序', '70', '0', 'Config/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('120', '排序', '75', '0', 'Menu/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('121', '排序', '76', '0', 'Channel/sort', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('122', '数据列表', '58', '0', 'think/lists', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('123', '审核列表', '3', '0', 'Article/examine', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('124', '站点管理', '0', '2', 'Site/index', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('125', '站点列表', '124', '0', 'Site/temp', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('126', '我的站点', '124', '0', 'SIte/temp', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('127', '个人中心', '0', '8', 'Profile/index', '1', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('128', '我的资料', '127', '0', 'Profile/info', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('129', '我的站点', '127', '0', 'Profile/site', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('130', '栏目管理', '129', '0', 'Profile/cate', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('131', '文章管理', '129', '0', 'Profile/article', '0', '', '', '0', '1');
INSERT INTO `onethink_menu` VALUES ('132', '导航管理', '129', '0', 'Profile/channel', '0', '', '', '0', '1');

-- -----------------------------
-- Table structure for `onethink_model`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_model`;
CREATE TABLE `onethink_model` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '模型ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '模型标识',
  `title` char(30) NOT NULL DEFAULT '' COMMENT '模型名称',
  `extend` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '继承的模型',
  `relation` varchar(30) NOT NULL DEFAULT '' COMMENT '继承与被继承模型的关联字段',
  `need_pk` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '新建表时是否需要主键字段',
  `field_sort` text COMMENT '表单字段排序',
  `field_group` varchar(255) NOT NULL DEFAULT '1:基础' COMMENT '字段分组',
  `attribute_list` text COMMENT '属性列表（表的字段）',
  `attribute_alias` varchar(255) NOT NULL DEFAULT '' COMMENT '属性别名定义',
  `template_list` varchar(100) NOT NULL DEFAULT '' COMMENT '列表模板',
  `template_add` varchar(100) NOT NULL DEFAULT '' COMMENT '新增模板',
  `template_edit` varchar(100) NOT NULL DEFAULT '' COMMENT '编辑模板',
  `list_grid` text COMMENT '列表定义',
  `list_row` smallint(2) unsigned NOT NULL DEFAULT '10' COMMENT '列表数据长度',
  `search_key` varchar(50) NOT NULL DEFAULT '' COMMENT '默认搜索字段',
  `search_list` varchar(255) NOT NULL DEFAULT '' COMMENT '高级搜索的字段',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '状态',
  `engine_type` varchar(25) NOT NULL DEFAULT 'MyISAM' COMMENT '数据库引擎',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='文档模型表';

-- -----------------------------
-- Records of `onethink_model`
-- -----------------------------
INSERT INTO `onethink_model` VALUES ('1', 'document', '基础文档', '0', '', '1', '{\"1\":[\"1\",\"2\",\"3\",\"4\",\"5\",\"6\",\"7\",\"8\",\"9\",\"10\",\"11\",\"12\",\"13\",\"14\",\"15\",\"16\",\"17\",\"18\",\"19\",\"20\",\"21\",\"22\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题:[EDIT]\r\ntype:类型\r\nupdate_time:最后更新\r\nstatus:状态\r\nview:浏览\r\nid:操作:[EDIT]|编辑,[DELETE]|删除', '0', '', '', '1383891233', '1384507827', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('2', 'article', '文章', '1', '', '1', '{\"1\":[\"3\",\"44\",\"5\",\"24\",\"2\"],\"2\":[\"9\",\"13\",\"19\",\"10\",\"12\",\"16\",\"17\",\"26\",\"20\",\"14\",\"11\",\"25\"]}', '1:基础,2:扩展', '', '', '', '', '', 'id:编号\r\ntitle:标题', '0', '', '', '1383891243', '1439955681', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('3', 'download', '下载', '1', '', '1', '{\"1\":[\"3\",\"28\",\"30\",\"32\",\"2\",\"5\",\"31\"],\"2\":[\"13\",\"10\",\"27\",\"9\",\"12\",\"16\",\"17\",\"19\",\"11\",\"20\",\"14\",\"29\"]}', '1:基础,2:扩展', '', '', '', '', '', '', '0', '', '', '1383891252', '1387260449', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('4', 'site', '公司网站', '0', '', '1', '{\"1\":[\"36\",\"35\",\"34\",\"33\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\nname:站点名称\r\ndomain:主域名\r\nmanage:管理员\r\nstatus:状态', '10', '', '', '1438139623', '1438139678', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('5', 'single', '单页', '1', '', '1', '{\"1\":[\"3\",\"44\",\"5\",\"41\",\"2\"],\"2\":[\"16\",\"14\",\"13\",\"12\",\"17\",\"20\",\"19\",\"11\",\"10\",\"9\"]}', '1:基础;2:扩展', '', '', '', '', '', 'category:分类', '10', '', '', '1438739447', '1438915485', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('6', 'product', '产品', '1', '', '1', '{\"1\":[\"3\",\"44\",\"5\",\"47\",\"46\",\"12\",\"45\",\"2\"],\"2\":[\"16\",\"20\",\"13\",\"19\",\"14\",\"9\",\"10\",\"11\",\"17\"]}', '1:基础;2:扩展', '', '', '', '', '', 'id:编号\r\ntitle:标题', '10', '', '', '1439955061', '1439955310', '1', 'MyISAM');
INSERT INTO `onethink_model` VALUES ('7', 'channel', '导航', '0', '', '1', '{\"1\":[\"54\",\"55\",\"56\",\"53\",\"52\",\"49\",\"50\",\"51\",\"48\"]}', '1:基础', '', '', '', '', '', 'id:编号\r\ntitle:标题\r\nurl:链接', '10', '', '', '1439966334', '1439966382', '1', 'MyISAM');

-- -----------------------------
-- Table structure for `onethink_picture`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_picture`;
CREATE TABLE `onethink_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `onethink_picture`
-- -----------------------------
INSERT INTO `onethink_picture` VALUES ('1', '/Uploads/Picture/2015-08-19/55d425a3bc837.jpg', '', '6fed1b406cd2551eca743e4df2513e51', '95b5e750cfdb6bc3ca82a56d97692e55a91ee0c6', '1', '1439966627');
INSERT INTO `onethink_picture` VALUES ('2', '/Uploads/Picture/2015-08-19/55d425bb8d8e5.jpg', '', '0d945977ed80c237bbadeaf63d7af009', 'a48a255d13ea3209b40e4226c98c629bf0ff21e1', '1', '1439966650');
INSERT INTO `onethink_picture` VALUES ('3', '/Uploads/Picture/2015-08-21/55d6da80049c7.gif', '', '0ce5f3786dd3ba6adc0aab2e4900989c', 'f01523ae92947b90176809c8d2409cced1aabfb3', '1', '1440143999');
INSERT INTO `onethink_picture` VALUES ('4', '/Uploads/Picture/2015-08-21/55d6da9bb3154.gif', '', '0435d4a65551898f7924b10249003803', '1e70c3cd0f8e64ff92540ed0eb1edc95a9a7fe98', '1', '1440144027');
INSERT INTO `onethink_picture` VALUES ('5', '/Uploads/Picture/2015-08-21/55d6dab6e8ee2.gif', '', '976747f6bc9ba46c3a49158ed9ee085c', 'fabd1f66c003fb564361a0e719c284670200e46a', '1', '1440144054');
INSERT INTO `onethink_picture` VALUES ('6', '/Uploads/Picture/2015-08-21/55d6dad34da63.gif', '', 'c4860b4da35f3dbed93208e74bbb2fd7', '48865991a0a52014fc5953b1698a186fbb18992d', '1', '1440144083');
INSERT INTO `onethink_picture` VALUES ('7', '/Uploads/Picture/2015-08-21/55d6daef75b9f.gif', '', '7a357f2595264b980e2b881039950466', '2d3734b281bb3075969c62afe7fdabc2019e4157', '1', '1440144111');
INSERT INTO `onethink_picture` VALUES ('8', '/Uploads/Picture/2015-08-21/55d6db159e166.gif', '', 'db9f7bd754f554306256f8b36643f13d', 'ac55dd4699f0c5392fcf00864fa0b444d6b1a2c1', '1', '1440144149');
INSERT INTO `onethink_picture` VALUES ('9', '/Uploads/Picture/2015-08-21/55d6db58d911c.gif', '', 'c9dc1a31d0b626baec8b1b07d52b1585', '7c60083d95aaf032d7fba0235eb01bcd1fbc1842', '1', '1440144216');
INSERT INTO `onethink_picture` VALUES ('10', '/Uploads/Picture/2015-08-21/55d6db80e550a.gif', '', '0d3b58f83e96a94eb551adb08e7c0315', '95e71ee2935e3555b30200f345e1295fe4376186', '1', '1440144256');
INSERT INTO `onethink_picture` VALUES ('11', '/Uploads/Picture/2015-08-21/55d6dbaadc0ed.gif', '', '022b67b8ce5dbfb39555f75a0b282e45', 'c3626c499c17f26b9721122dec7f8cf1bb0eedba', '1', '1440144298');
INSERT INTO `onethink_picture` VALUES ('12', '/Uploads/Picture/2015-08-21/55d6dbdc47336.gif', '', 'a50a360f767a8d2af8eeacac49638bc9', '9a07be8211e663b85e55e9273428cc06ff541abc', '1', '1440144348');
INSERT INTO `onethink_picture` VALUES ('13', '/Uploads/Picture/2015-08-21/55d6dc01cc245.gif', '', 'abffd373afeb28d9e537bdc3a1f80355', 'e96dce1f4434e5a7c91d13b930138124af203d60', '1', '1440144385');
INSERT INTO `onethink_picture` VALUES ('14', '/Uploads/Picture/2015-08-21/55d6dc29d2a8c.gif', '', '98708e0ef5627f51a4423de08726eab0', '1adaffaac58f1a9b0a0a42fe8c797552252df9b0', '1', '1440144425');
INSERT INTO `onethink_picture` VALUES ('15', '/Uploads/Picture/2015-08-21/55d6dc4d3c929.gif', '', '6a50324ee5c1fed0ab53aab024b1b142', '21ca65eafddf2936605fefa7003ae06bc33c3770', '1', '1440144461');
INSERT INTO `onethink_picture` VALUES ('16', '/Uploads/Picture/2015-08-21/55d6dc9ed1206.gif', '', 'e0159e519180b2782bdfbcd1a0e338a4', '3e4ff0784a1a6d25645972f664cb8f7e9c637d8b', '1', '1440144542');
INSERT INTO `onethink_picture` VALUES ('17', '/Uploads/Picture/2015-08-21/55d6dcc72bd1c.gif', '', 'b7d543cabb097d3b8a0ff706e46255d6', 'cdf2083e7f1ebb56a571971b864cbac84f667177', '1', '1440144583');
INSERT INTO `onethink_picture` VALUES ('18', '/Uploads/Picture/2015-08-21/55d6dced7b0ad.gif', '', '683ca69d26475866b87d077b1759c4a5', 'd2632d46505a0aa6420fec8bc849d6d06f4cac14', '1', '1440144621');
INSERT INTO `onethink_picture` VALUES ('19', '/Uploads/Picture/2015-08-21/55d6dd109429c.gif', '', '3d1a0c12397179f84e403f7d744ec2b7', '2b2740fe14aeeadeabbc73ebf92ff60e585c7de2', '1', '1440144656');
INSERT INTO `onethink_picture` VALUES ('20', '/Uploads/Picture/2015-08-21/55d6dd3448e20.gif', '', '9a3b05dfe15d0a24b56c0506eaebebed', '5a4f2ae55f7e1e3840b19d05e2a2277a68be55c3', '1', '1440144692');
INSERT INTO `onethink_picture` VALUES ('21', '/Uploads/Picture/2015-08-21/55d6e28fe555b.gif', '', '1a1f1c9261ce1b145590ed0cf6dd5b17', '00aa47505540c269da76846bc61043b3b3894c3d', '1', '1440146063');
INSERT INTO `onethink_picture` VALUES ('22', '/Uploads/Picture/2015-08-21/55d6e645e4fab.png', '', '197d0bfc6c888f1af21ef07eaf4abaad', '6acc6eb868f839a24f1736aee53e48bb565d39eb', '1', '1440147013');
INSERT INTO `onethink_picture` VALUES ('23', '/Uploads/Picture/2015-08-24/55da7e8ef1684.png', '', '94d6cbec09142db8ef59f0cc13ace87b', 'f9fdef509e5617323c418d7adfb001651b99a1ee', '1', '1440382604');
INSERT INTO `onethink_picture` VALUES ('24', '/Uploads/Picture/2015-08-24/55da7e9b41deb.png', '', '2de4260a9161f80707bfdaa5e6dd870a', '1ecea0089abdedde9aa8a522550204a3de4a0fb6', '1', '1440382618');
INSERT INTO `onethink_picture` VALUES ('25', '/Uploads/Picture/2015-08-24/55dae124a573e.png', '', '0a99efed40e00215453a72dcb65ac62c', 'a9190466d499aef4aa23c647ec78a39ad41ed3bc', '1', '1440407844');
INSERT INTO `onethink_picture` VALUES ('26', '/Uploads/Picture/2015-08-24/55dae38c8d14a.png', '', '65748422c187942741f7d620eeabda5e', '63706ecb30267ef2615c1b0e93b1dfb365f4c621', '1', '1440408460');
INSERT INTO `onethink_picture` VALUES ('27', '/Uploads/Picture/2015-08-24/55dae39924b53.png', '', '71aed14a8cf4dcb66c6377995567a3b1', '85c3011c6ef0c26debac4b040d502d59bfd89a77', '1', '1440408472');

-- -----------------------------
-- Table structure for `onethink_site`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_site`;
CREATE TABLE `onethink_site` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '站点名称',
  `domain` varchar(20) NOT NULL COMMENT '域名',
  `manage` int(10) unsigned NOT NULL COMMENT '管理员',
  `status` char(50) NOT NULL COMMENT '状态',
  `title` varchar(255) NOT NULL COMMENT 'title',
  `description` varchar(255) NOT NULL COMMENT 'description',
  `keywords` varchar(255) NOT NULL COMMENT 'keywords',
  `theme` varchar(100) NOT NULL COMMENT '模板',
  `config` text NOT NULL COMMENT '站点设置',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- -----------------------------
-- Records of `onethink_site`
-- -----------------------------
INSERT INTO `onethink_site` VALUES ('1', '南京楷伦官网', 'canopharm.com', '2', '1', '南京楷伦生物医药科技有限公司', '南京楷伦生物医药科技有限公司专注于新型手性催化技术开发及手性药物产业化研究，致力于为国内外制药企业，新药研发机构，科研院所，高校等提供国际领先，优质，经济的新型手性技术开发与手性药物制备一站式服务。', '南京楷伦生物医药科技有限公司，手性催化技术', 'nanjing', '{\"MULTI_TITLE\":\"2\",\"URL_MODEL\":\"2\",\"SITE_LIST_ROW\":\"8\"}');
INSERT INTO `onethink_site` VALUES ('2', '南京楷伦英文站', 'en.canopharm.com', '2', '1', 'NANJING KAILUN BIO-TECHNOLOGY CO.,LTD', 'NANJING KAILUN BIO-TECHNOLOGY CO.,LTD', 'NANJING KAILUN BIO-TECHNOLOGY CO.,LTD', 'nanjing_en', '{\"DEFAULT_LANG\":\"en-us\",\"MULTI_TITLE\":\"2\",\"URL_MODEL\":\"2\",\"SITE_LIST_ROW\":\"8\"}');

-- -----------------------------
-- Table structure for `onethink_ucenter_admin`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_admin`;
CREATE TABLE `onethink_ucenter_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `member_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员用户ID',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '管理员状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='管理员表';


-- -----------------------------
-- Table structure for `onethink_ucenter_app`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_app`;
CREATE TABLE `onethink_ucenter_app` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '应用ID',
  `title` varchar(30) NOT NULL COMMENT '应用名称',
  `url` varchar(100) NOT NULL COMMENT '应用URL',
  `ip` char(15) NOT NULL DEFAULT '' COMMENT '应用IP',
  `auth_key` varchar(100) NOT NULL DEFAULT '' COMMENT '加密KEY',
  `sys_login` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '同步登陆',
  `allow_ip` varchar(255) NOT NULL DEFAULT '' COMMENT '允许访问的IP',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '应用状态',
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='应用表';


-- -----------------------------
-- Table structure for `onethink_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_member`;
CREATE TABLE `onethink_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `mobile` char(15) NOT NULL DEFAULT '' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `onethink_ucenter_member`
-- -----------------------------
INSERT INTO `onethink_ucenter_member` VALUES ('1', 'admin', '84e75518306414a3ae083765413b520b', '1498518288@qq.com', '', '1439954995', '454105574', '1440985221', '454105574', '1439954995', '1');
INSERT INTO `onethink_ucenter_member` VALUES ('2', 'canopharm', '92548ce91cd3046d009b8e387b568d74', 'test@canopharm.com', '', '1440140643', '454105574', '1440984977', '454105574', '1440140643', '1');

-- -----------------------------
-- Table structure for `onethink_ucenter_setting`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_ucenter_setting`;
CREATE TABLE `onethink_ucenter_setting` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '设置ID',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型（1-用户配置）',
  `value` text NOT NULL COMMENT '配置数据',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='设置表';


-- -----------------------------
-- Table structure for `onethink_url`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_url`;
CREATE TABLE `onethink_url` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '链接唯一标识',
  `url` char(255) NOT NULL DEFAULT '' COMMENT '链接地址',
  `short` char(100) NOT NULL DEFAULT '' COMMENT '短网址',
  `status` tinyint(2) NOT NULL DEFAULT '2' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='链接表';


-- -----------------------------
-- Table structure for `onethink_userdata`
-- -----------------------------
DROP TABLE IF EXISTS `onethink_userdata`;
CREATE TABLE `onethink_userdata` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户id',
  `type` tinyint(3) unsigned NOT NULL COMMENT '类型标识',
  `target_id` int(10) unsigned NOT NULL COMMENT '目标id',
  UNIQUE KEY `uid` (`uid`,`type`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

